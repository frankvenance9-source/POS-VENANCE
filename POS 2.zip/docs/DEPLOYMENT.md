# ============================================================
#  POS & Retail Management System — Deployment Guide
#  Currency: TZS (Tanzanian Shillings)
# ============================================================

## SYSTEM OVERVIEW

```
┌─────────────────────────────────────────────────────────────┐
│                    POS System Architecture                   │
├─────────────────────────────────────────────────────────────┤
│  Frontend (React)     │  Backend (Node.js/Express)          │
│  ─────────────────    │  ───────────────────────            │
│  • POS Interface      │  • REST API (/api/v1)               │
│  • Admin Dashboard    │  • JWT Authentication               │
│  • Offline Mode (IDB) │  • Role-Based Access Control        │
│  • Receipt Printing   │  • WebSocket (Socket.io)            │
│                       │  • Scheduled backups                │
├───────────────────────┴─────────────────────────────────────┤
│  Database: MySQL 8.0                                        │
│  Tables: branches, users, products, inventory, sales,       │
│          purchase_orders, grns, customers, expenses, ...     │
├─────────────────────────────────────────────────────────────┤
│  Web Server: Nginx (reverse proxy + SSL termination)        │
└─────────────────────────────────────────────────────────────┘
```

---

## RECOMMENDED HOSTING (Tanzania)

### Option A — VPS (Best for full control)
- **DigitalOcean** / **Vultr** / **Linode** — $12–24/mo
- Ubuntu 22.04 LTS, 2GB RAM, 50GB SSD
- Domain registrar: **Zicta** (.co.tz) or Namecheap

### Option B — Shared/cPanel Hosting
- Upload frontend build to `public_html`
- Run Node backend on a port (Node.js supported by Namecheap/SiteGround)

### Option C — Cloud Platform
- Railway.app or Render.com (free tiers available)
- PlanetScale for MySQL

---

## STEP-BY-STEP SETUP

### 1. Server Preparation (Ubuntu 22.04)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MySQL
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Install Nginx
sudo apt install -y nginx

# Install PM2 (process manager)
sudo npm install -g pm2

# Install Certbot for SSL
sudo apt install -y certbot python3-certbot-nginx
```

### 2. MySQL Database Setup

```sql
-- Connect as root
mysql -u root -p

-- Create database and user
CREATE DATABASE pos_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'pos_user'@'localhost' IDENTIFIED BY 'YourStrongPassword123!';
GRANT ALL PRIVILEGES ON pos_system.* TO 'pos_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

-- Import schema
mysql -u pos_user -p pos_system < /path/to/database/schema.sql
```

### 3. Backend Setup

```bash
# Clone or upload your project
cd /var/www
mkdir pos-system && cd pos-system

# Copy backend files
# (upload via SFTP/SCP)

cd backend
npm install --production

# Configure environment
cp .env.example .env
nano .env  # Fill in your values:
# DB_HOST=localhost
# DB_USER=pos_user
# DB_PASSWORD=YourStrongPassword123!
# DB_NAME=pos_system
# JWT_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))">
# FRONTEND_URL=https://yourdomain.co.tz
# NODE_ENV=production

# Create uploads directory
mkdir -p uploads backups

# Start with PM2
pm2 start server.js --name pos-backend
pm2 startup  # Enable auto-start on reboot
pm2 save
```

### 4. Frontend Build & Deploy

```bash
cd ../frontend

# Install dependencies
npm install

# Set API URL
echo "REACT_APP_API_URL=https://yourdomain.co.tz/api/v1" > .env.production

# Build for production
npm run build

# Copy build to web root
sudo cp -r build/* /var/www/html/pos/
```

### 5. Nginx Configuration

```nginx
# /etc/nginx/sites-available/pos-system
server {
    listen 80;
    server_name yourdomain.co.tz www.yourdomain.co.tz;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.co.tz www.yourdomain.co.tz;

    # SSL (managed by Certbot)
    ssl_certificate     /etc/letsencrypt/live/yourdomain.co.tz/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.co.tz/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";

    # Gzip
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    # React frontend
    root /var/www/html/pos;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
        expires 1d;
    }

    # Static assets — long cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # API proxy → Node.js backend
    location /api/ {
        proxy_pass         http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 60s;
        client_max_body_size 10M;
    }

    # Uploads directory
    location /uploads/ {
        alias /var/www/pos-system/backend/uploads/;
        expires 7d;
    }

    # WebSocket (Socket.io)
    location /socket.io/ {
        proxy_pass         http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection "upgrade";
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/pos-system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Issue SSL certificate
sudo certbot --nginx -d yourdomain.co.tz -d www.yourdomain.co.tz
```

---

## DEFAULT LOGIN CREDENTIALS

| Email                 | Password    | Role  |
|-----------------------|-------------|-------|
| admin@myshop.co.tz   | Admin@1234  | Admin |

**⚠️ Change the password immediately after first login!**

---

## USER ROLES & ACCESS

| Feature              | Admin | Manager | Cashier | Stock Mgr |
|---------------------|-------|---------|---------|-----------|
| POS / Sales         | ✅    | ✅      | ✅      | ❌        |
| Products             | ✅    | ✅      | ❌      | ✅        |
| Inventory            | ✅    | ✅      | ❌      | ✅        |
| Purchases            | ✅    | ✅      | ❌      | ✅        |
| Customers            | ✅    | ✅      | ✅      | ❌        |
| Expenses             | ✅    | ✅      | ❌      | ❌        |
| Reports / P&L        | ✅    | ✅      | ❌      | ❌        |
| Users & Settings     | ✅    | ❌      | ❌      | ❌        |
| Audit Log            | ✅    | ❌      | ❌      | ❌        |

---

## PAYMENT METHODS (Pre-configured)

| Method         | Provider                       |
|----------------|--------------------------------|
| Cash           | Direct cash                    |
| M-Pesa         | Vodacom M-Pesa                 |
| Tigo Pesa      | Tigo Tanzania                  |
| Airtel Money   | Airtel Tanzania                |
| Bank Transfer  | NMB / CRDB / Stanbic           |
| Card Payment   | Visa / Mastercard (optional)   |
| Credit Account | Customer credit (deferred pay) |

Configure payment method details in **Settings → Payment Methods**.

---

## BARCODE LABEL PRINTING

The system supports thermal label printers (Zebra, TSC, Godex):

1. Products → Find product → Click barcode icon
2. Choose label format (product name + barcode + price)
3. Connect thermal printer via USB or network
4. Print directly from browser using system print dialog

Supported barcode formats: **CODE128** (default) and **EAN13**

---

## OFFLINE POS MODE

When internet is unavailable:
1. POS continues working — product data cached in browser (IndexedDB)
2. Sales queued locally in browser storage
3. When internet restores → "Sync" button appears in POS header
4. Offline sales automatically sent to server and reconciled

Cache products manually: Settings → Offline Mode → Sync Product Cache

---

## RECEIPT CUSTOMIZATION

Settings → Receipt Settings:
- Shop name, address, phone
- Logo image (upload)
- Footer message (default: "Asante kwa kununua! Karibuni tena.")
- TAX rate (VAT if applicable)
- Thermal printer: set paper size to 80mm × auto

---

## BACKUP & RESTORE

Automatic backups run daily at 01:00 AM (EAT).
Stored in `/var/www/pos-system/backend/backups/`
Kept for 30 days (configurable in .env).

Manual backup:
```bash
mysqldump -u pos_user -p pos_system > backup-manual-$(date +%F).sql
```

Restore:
```bash
mysql -u pos_user -p pos_system < backup-2025-01-15.sql
```

---

## API ENDPOINTS REFERENCE

```
Authentication
  POST /api/v1/auth/login
  GET  /api/v1/auth/me

Products
  GET  /api/v1/products
  POST /api/v1/products
  GET  /api/v1/products/barcode/:code
  PUT  /api/v1/products/:id

Sales
  GET  /api/v1/sales
  POST /api/v1/sales           ← Main POS checkout
  GET  /api/v1/sales/daily-summary
  POST /api/v1/sales/:id/refund
  POST /api/v1/sales/sync-offline

Inventory
  GET  /api/v1/inventory
  POST /api/v1/inventory/adjust
  GET  /api/v1/inventory/movements
  POST /api/v1/inventory/transfers
  POST /api/v1/inventory/transfers/:id/dispatch
  POST /api/v1/inventory/transfers/:id/receive

Purchases
  GET  /api/v1/suppliers
  POST /api/v1/purchase-orders
  POST /api/v1/grns
  POST /api/v1/grns/:id/confirm   ← Updates inventory

Customers
  GET  /api/v1/customers
  GET  /api/v1/customers/:id/statement
  POST /api/v1/customers/:id/credit-payment

Reports
  GET  /api/v1/reports/dashboard
  GET  /api/v1/reports/profit-loss
  GET  /api/v1/reports/sales
  GET  /api/v1/reports/top-products
  GET  /api/v1/reports/inventory-valuation
  GET  /api/v1/reports/export/excel
  GET  /api/v1/reports/export/pdf

Admin
  GET  /api/v1/users
  GET  /api/v1/branches
  GET  /api/v1/settings
  PUT  /api/v1/settings
  GET  /api/v1/audit-logs
```

---

## TECH STACK

| Layer      | Technology              | Version  |
|------------|-------------------------|----------|
| Frontend   | React                   | 18.x     |
| Routing    | React Router DOM        | 6.x      |
| State      | Zustand                 | 4.x      |
| Charts     | Recharts                | 2.x      |
| Styling    | Tailwind CSS            | 3.x      |
| Offline    | IndexedDB (idb)         | 7.x      |
| Printing   | react-to-print          | 2.x      |
| Backend    | Node.js + Express       | 20.x     |
| ORM        | Sequelize               | 6.x      |
| Database   | MySQL                   | 8.0      |
| Auth       | JWT + bcrypt            | -        |
| 2FA        | speakeasy (TOTP/HOTP)   | 2.x      |
| Barcodes   | bwip-js                 | 4.x      |
| Exports    | ExcelJS + PDFKit        | -        |
| Real-time  | Socket.io               | 4.x      |
| Scheduler  | node-cron               | 3.x      |
| Web Server | Nginx                   | 1.24     |
| Process    | PM2                     | 5.x      |

---

## SUPPORT & CUSTOMIZATION

The system is modular — each controller and page can be extended:

- Add new payment methods via Settings UI
- Add new expense categories via database enum
- Add new branches via Admin → Branches
- Customize receipt template via Settings → Receipt
- Add products in bulk via CSV import (add to productsController)

For questions or customizations contact your system administrator.
