-- ============================================================
--  POS & Retail Management System — Database Schema
--  Currency: TZS (Tanzanian Shillings)
--  Version: 1.0.0
-- ============================================================

CREATE DATABASE IF NOT EXISTS pos_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_system;

-- -------------------------
-- BRANCHES / LOCATIONS
-- -------------------------
CREATE TABLE branches (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  address     TEXT,
  phone       VARCHAR(20),
  type        ENUM('shop','warehouse','branch') DEFAULT 'shop',
  is_active   BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -------------------------
-- USERS
-- -------------------------
CREATE TABLE users (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  name                VARCHAR(100) NOT NULL,
  email               VARCHAR(100) UNIQUE NOT NULL,
  password            VARCHAR(255) NOT NULL,
  role                ENUM('admin','manager','cashier','stock_manager') NOT NULL DEFAULT 'cashier',
  branch_id           INT,
  phone               VARCHAR(20),
  is_active           BOOLEAN DEFAULT TRUE,
  two_factor_secret   VARCHAR(255),
  two_factor_enabled  BOOLEAN DEFAULT FALSE,
  last_login          TIMESTAMP NULL,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL
);

-- -------------------------
-- CATEGORIES
-- -------------------------
CREATE TABLE categories (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100) NOT NULL,
  description     TEXT,
  default_markup  DECIMAL(5,2) DEFAULT 30.00,
  parent_id       INT DEFAULT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- -------------------------
-- SUPPLIERS
-- -------------------------
CREATE TABLE suppliers (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100) NOT NULL,
  contact_person  VARCHAR(100),
  phone           VARCHAR(20),
  email           VARCHAR(100),
  address         TEXT,
  tax_number      VARCHAR(50),
  notes           TEXT,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -------------------------
-- PRODUCTS
-- -------------------------
CREATE TABLE products (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(200) NOT NULL,
  category_id       INT,
  barcode           VARCHAR(50) UNIQUE,
  sku               VARCHAR(50) UNIQUE,
  cost_price        DECIMAL(15,2) NOT NULL DEFAULT 0,
  selling_price     DECIMAL(15,2) NOT NULL DEFAULT 0,
  markup_percentage DECIMAL(5,2)  DEFAULT 30.00,
  unit_of_measure   VARCHAR(20)   DEFAULT 'pcs',
  supplier_id       INT,
  reorder_level     INT DEFAULT 0,
  description       TEXT,
  image_url         VARCHAR(500),
  barcode_type      ENUM('CODE128','EAN13') DEFAULT 'CODE128',
  is_active         BOOLEAN DEFAULT TRUE,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id)  REFERENCES categories(id) ON DELETE SET NULL,
  FOREIGN KEY (supplier_id)  REFERENCES suppliers(id)  ON DELETE SET NULL
);

-- -------------------------
-- INVENTORY (stock per branch)
-- -------------------------
CREATE TABLE inventory (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  product_id  INT NOT NULL,
  branch_id   INT NOT NULL,
  quantity    DECIMAL(15,3) DEFAULT 0,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_product_branch (product_id, branch_id),
  FOREIGN KEY (product_id) REFERENCES products(id)  ON DELETE CASCADE,
  FOREIGN KEY (branch_id)  REFERENCES branches(id)  ON DELETE CASCADE
);

-- -------------------------
-- STOCK MOVEMENT LEDGER
-- -------------------------
CREATE TABLE stock_movements (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  product_id      INT NOT NULL,
  branch_id       INT NOT NULL,
  type            ENUM('purchase','sale','adjustment','transfer_in','transfer_out','opening','return','damage') NOT NULL,
  quantity        DECIMAL(15,3) NOT NULL,
  balance_after   DECIMAL(15,3),
  unit_cost       DECIMAL(15,2),
  reference_id    INT,
  reference_type  VARCHAR(50),
  notes           TEXT,
  created_by      INT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (branch_id)  REFERENCES branches(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- -------------------------
-- CUSTOMERS
-- -------------------------
CREATE TABLE customers (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  name                VARCHAR(100) NOT NULL,
  phone               VARCHAR(20),
  email               VARCHAR(100),
  address             TEXT,
  credit_limit        DECIMAL(15,2) DEFAULT 0,
  outstanding_balance DECIMAL(15,2) DEFAULT 0,
  is_active           BOOLEAN DEFAULT TRUE,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -------------------------
-- SALES
-- -------------------------
CREATE TABLE sales (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  receipt_number  VARCHAR(50) UNIQUE NOT NULL,
  branch_id       INT NOT NULL,
  customer_id     INT,
  cashier_id      INT NOT NULL,
  subtotal        DECIMAL(15,2) NOT NULL DEFAULT 0,
  discount        DECIMAL(15,2) DEFAULT 0,
  tax_amount      DECIMAL(15,2) DEFAULT 0,
  total           DECIMAL(15,2) NOT NULL DEFAULT 0,
  cost_total      DECIMAL(15,2) DEFAULT 0,
  profit          DECIMAL(15,2) DEFAULT 0,
  payment_method  ENUM('cash','mobile_money','bank_transfer','card','credit','mixed') DEFAULT 'cash',
  amount_paid     DECIMAL(15,2) DEFAULT 0,
  change_amount   DECIMAL(15,2) DEFAULT 0,
  credit_amount   DECIMAL(15,2) DEFAULT 0,
  status          ENUM('completed','pending','cancelled','refunded') DEFAULT 'completed',
  notes           TEXT,
  synced          BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id)   REFERENCES branches(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  FOREIGN KEY (cashier_id)  REFERENCES users(id)
);

-- -------------------------
-- SALE ITEMS
-- -------------------------
CREATE TABLE sale_items (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  sale_id     INT NOT NULL,
  product_id  INT NOT NULL,
  quantity    DECIMAL(15,3) NOT NULL,
  unit_price  DECIMAL(15,2) NOT NULL,
  cost_price  DECIMAL(15,2) NOT NULL DEFAULT 0,
  discount    DECIMAL(15,2) DEFAULT 0,
  total       DECIMAL(15,2) NOT NULL,
  profit      DECIMAL(15,2) DEFAULT 0,
  FOREIGN KEY (sale_id)    REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- -------------------------
-- PAYMENT DETAILS (for mixed/split payments)
-- -------------------------
CREATE TABLE payment_details (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  sale_id         INT NOT NULL,
  payment_method  ENUM('cash','mobile_money','bank_transfer','card','credit') NOT NULL,
  amount          DECIMAL(15,2) NOT NULL,
  reference       VARCHAR(100),
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
);

-- -------------------------
-- CREDIT PAYMENTS
-- -------------------------
CREATE TABLE credit_payments (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  customer_id     INT NOT NULL,
  sale_id         INT,
  amount          DECIMAL(15,2) NOT NULL,
  payment_method  ENUM('cash','mobile_money','bank_transfer','card') DEFAULT 'cash',
  reference       VARCHAR(100),
  received_by     INT,
  notes           TEXT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (sale_id)     REFERENCES sales(id) ON DELETE SET NULL,
  FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL
);

-- -------------------------
-- PURCHASE ORDERS
-- -------------------------
CREATE TABLE purchase_orders (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  po_number       VARCHAR(50) UNIQUE NOT NULL,
  supplier_id     INT NOT NULL,
  branch_id       INT NOT NULL,
  status          ENUM('draft','sent','partial','received','cancelled') DEFAULT 'draft',
  subtotal        DECIMAL(15,2) DEFAULT 0,
  tax_amount      DECIMAL(15,2) DEFAULT 0,
  total           DECIMAL(15,2) DEFAULT 0,
  notes           TEXT,
  ordered_by      INT,
  expected_date   DATE,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
  FOREIGN KEY (branch_id)   REFERENCES branches(id),
  FOREIGN KEY (ordered_by)  REFERENCES users(id) ON DELETE SET NULL
);

-- -------------------------
-- PURCHASE ORDER ITEMS
-- -------------------------
CREATE TABLE purchase_order_items (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  po_id               INT NOT NULL,
  product_id          INT NOT NULL,
  quantity_ordered    DECIMAL(15,3) NOT NULL,
  quantity_received   DECIMAL(15,3) DEFAULT 0,
  unit_cost           DECIMAL(15,2) NOT NULL,
  total               DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (po_id)       REFERENCES purchase_orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id)  REFERENCES products(id)
);

-- -------------------------
-- GOODS RECEIPT NOTES (GRN)
-- -------------------------
CREATE TABLE grns (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  grn_number    VARCHAR(50) UNIQUE NOT NULL,
  po_id         INT,
  supplier_id   INT NOT NULL,
  branch_id     INT NOT NULL,
  status        ENUM('draft','confirmed') DEFAULT 'draft',
  total_cost    DECIMAL(15,2) DEFAULT 0,
  notes         TEXT,
  received_by   INT,
  received_at   TIMESTAMP NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (po_id)       REFERENCES purchase_orders(id) ON DELETE SET NULL,
  FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
  FOREIGN KEY (branch_id)   REFERENCES branches(id),
  FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL
);

-- -------------------------
-- GRN ITEMS
-- -------------------------
CREATE TABLE grn_items (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  grn_id              INT NOT NULL,
  product_id          INT NOT NULL,
  quantity_received   DECIMAL(15,3) NOT NULL,
  unit_cost           DECIMAL(15,2) NOT NULL,
  total               DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (grn_id)      REFERENCES grns(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id)  REFERENCES products(id)
);

-- -------------------------
-- STOCK TRANSFERS
-- -------------------------
CREATE TABLE stock_transfers (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  transfer_number VARCHAR(50) UNIQUE NOT NULL,
  from_branch_id  INT NOT NULL,
  to_branch_id    INT NOT NULL,
  status          ENUM('draft','in_transit','received','cancelled') DEFAULT 'draft',
  notes           TEXT,
  created_by      INT,
  approved_by     INT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (from_branch_id) REFERENCES branches(id),
  FOREIGN KEY (to_branch_id)   REFERENCES branches(id),
  FOREIGN KEY (created_by)     REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE stock_transfer_items (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  transfer_id  INT NOT NULL,
  product_id   INT NOT NULL,
  quantity     DECIMAL(15,3) NOT NULL,
  unit_cost    DECIMAL(15,2),
  FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id)  REFERENCES products(id)
);

-- -------------------------
-- EXPENSES
-- -------------------------
CREATE TABLE expenses (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  branch_id       INT NOT NULL,
  category        ENUM('transport','rent','utilities','salaries','miscellaneous','other') NOT NULL,
  description     TEXT,
  amount          DECIMAL(15,2) NOT NULL,
  payment_method  ENUM('cash','mobile_money','bank_transfer') DEFAULT 'cash',
  reference       VARCHAR(100),
  expense_date    DATE NOT NULL,
  recorded_by     INT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id)   REFERENCES branches(id),
  FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- -------------------------
-- PAYMENT METHODS CONFIG
-- -------------------------
CREATE TABLE payment_methods_config (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(50) NOT NULL,
  type        ENUM('cash','mobile_money','bank_transfer','card','credit') NOT NULL,
  details     TEXT,
  is_active   BOOLEAN DEFAULT TRUE
);

-- -------------------------
-- PHYSICAL STOCK COUNTS
-- -------------------------
CREATE TABLE stock_counts (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  branch_id     INT NOT NULL,
  status        ENUM('draft','completed') DEFAULT 'draft',
  counted_by    INT,
  notes         TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at  TIMESTAMP NULL,
  FOREIGN KEY (branch_id)  REFERENCES branches(id),
  FOREIGN KEY (counted_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE stock_count_items (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  count_id          INT NOT NULL,
  product_id        INT NOT NULL,
  system_quantity   DECIMAL(15,3),
  counted_quantity  DECIMAL(15,3),
  variance          DECIMAL(15,3) GENERATED ALWAYS AS (counted_quantity - system_quantity) STORED,
  FOREIGN KEY (count_id)    REFERENCES stock_counts(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id)  REFERENCES products(id)
);

-- -------------------------
-- SYSTEM SETTINGS
-- -------------------------
CREATE TABLE settings (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  `key`       VARCHAR(100) UNIQUE NOT NULL,
  `value`     TEXT,
  description VARCHAR(255),
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -------------------------
-- AUDIT TRAIL
-- -------------------------
CREATE TABLE audit_logs (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT,
  action      VARCHAR(100) NOT NULL,
  module      VARCHAR(50)  NOT NULL,
  description TEXT,
  ip_address  VARCHAR(45),
  old_values  JSON,
  new_values  JSON,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
--  SEED DATA
-- ============================================================

INSERT INTO branches (name, address, phone, type) VALUES
('Main Shop', 'Lindi Street, Dar es Salaam, Tanzania', '+255 700 000 000', 'shop'),
('Warehouse',  'Industrial Area, Dar es Salaam, Tanzania', '+255 700 000 001', 'warehouse');

-- Default admin password: Admin@1234
INSERT INTO users (name, email, password, role, branch_id) VALUES
('System Administrator', 'admin@myshop.co.tz',
 '$2b$12$LNHuD9hpYYqpTJgNHHbj2.BuI.6x4Qn4FQfEdJajGDq.CfbUqC.6e', 'admin', 1);

INSERT INTO categories (name, description, default_markup) VALUES
('General',            'General merchandise',          30.00),
('Electronics',        'Electronic products',           25.00),
('Food & Beverages',   'Food and drink products',       40.00),
('Clothing & Apparel', 'Clothes and accessories',       50.00),
('Household Items',    'Home and kitchen products',     35.00),
('Health & Beauty',    'Health and personal care',      45.00),
('Stationery',         'Office and school supplies',    40.00);

INSERT INTO settings (`key`, `value`, description) VALUES
('shop_name',            'My Retail Shop',                  'Business name displayed on receipts'),
('shop_address',         'Dar es Salaam, Tanzania',         'Business address'),
('shop_phone',           '+255 700 000 000',                'Business phone number'),
('shop_email',           'info@myshop.co.tz',              'Business email'),
('currency',             'TZS',                             'Currency code'),
('currency_symbol',      'TZS',                             'Currency display symbol'),
('receipt_footer',       'Asante kwa kununua! Karibuni tena.', 'Receipt footer text'),
('tax_rate',             '0',                               'VAT/Tax rate percentage'),
('default_markup',       '30',                              'Default markup percentage'),
('receipt_logo',         '',                                'URL of receipt logo image'),
('low_stock_email',      '',                                'Email for low stock alerts'),
('backup_frequency',     'daily',                           'Database backup frequency'),
('pos_branch_id',        '1',                               'Default POS branch'),
('invoice_prefix',       'RCP',                             'Receipt number prefix'),
('po_prefix',            'PO',                              'Purchase order prefix'),
('grn_prefix',           'GRN',                             'GRN number prefix'),
('transfer_prefix',      'TRF',                             'Transfer number prefix');

INSERT INTO payment_methods_config (name, type, details, is_active) VALUES
('Cash',           'cash',          NULL,                                     TRUE),
('M-Pesa',         'mobile_money',  'Vodacom M-Pesa — Till No: 123456',       TRUE),
('Tigo Pesa',      'mobile_money',  'Tigo Pesa — Account: 0712345678',        TRUE),
('Airtel Money',   'mobile_money',  'Airtel Money — Account: 0688123456',     TRUE),
('Bank Transfer',  'bank_transfer', 'NMB Bank — Account: 21310XXXXXXXXX',    TRUE),
('Card Payment',   'card',          'Visa / MasterCard',                      FALSE),
('Credit Account', 'credit',        'Customer credit account',                TRUE);

-- Indexes for performance
CREATE INDEX idx_sales_created_at     ON sales (created_at);
CREATE INDEX idx_sales_branch         ON sales (branch_id);
CREATE INDEX idx_sale_items_sale      ON sale_items (sale_id);
CREATE INDEX idx_sale_items_product   ON sale_items (product_id);
CREATE INDEX idx_stock_movements_prod ON stock_movements (product_id, branch_id);
CREATE INDEX idx_products_barcode     ON products (barcode);
CREATE INDEX idx_products_sku         ON products (sku);
CREATE INDEX idx_audit_logs_user      ON audit_logs (user_id, created_at);
CREATE INDEX idx_inventory_branch     ON inventory (branch_id);
