// ============================================================
//  POS System — Express Server Entry Point
// ============================================================
require('dotenv').config();

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const compression = require('compression');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const cron       = require('node-cron');

const { sequelize } = require('./src/config/database');
const routes        = require('./src/routes');
const { createBackup } = require('./src/utils/backup');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || '*', methods: ['GET','POST'] }
});

// ── Security ──────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.FRONTEND_URL || '*', credentials: true }));

// ── Rate limiting ─────────────────────────────────────────
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 500,
  message: { error: 'Too many requests, please try again later.' }
}));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 10 }));

// ── Body parsing & compression ────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(compression());

// ── Logging ───────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') app.use(morgan('combined'));

// ── Static files ──────────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Share Socket.io instance with routes ──────────────────
app.use((req, _res, next) => { req.io = io; next(); });

// ── API Routes ────────────────────────────────────────────
app.use(process.env.API_PREFIX || '/api/v1', routes);

// ── Health check ──────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: new Date() }));

// ── 404 ───────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));

// ── Global error handler ──────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  const status  = err.status || 500;
  const message = process.env.NODE_ENV === 'production'
    ? (status < 500 ? err.message : 'Internal server error')
    : err.message;
  res.status(status).json({ error: message });
});

// ── Scheduled tasks ───────────────────────────────────────
// Daily backup at 01:00
cron.schedule('0 1 * * *', () => {
  console.log('[CRON] Running daily backup...');
  createBackup().catch(console.error);
});
// Low-stock check every 6 hours
cron.schedule('0 */6 * * *', () => {
  console.log('[CRON] Checking low stock...');
  require('./src/utils/stockAlerts').checkLowStock().catch(console.error);
});

// ── Socket.io ─────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);
  socket.on('join_branch', (branchId) => socket.join(`branch_${branchId}`));
  socket.on('disconnect', () => console.log(`[WS] Client disconnected: ${socket.id}`));
});

// ── Start ─────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;

sequelize.authenticate()
  .then(() => {
    console.log('[DB] Database connection established.');
    server.listen(PORT, () => {
      console.log(`[SERVER] POS API running on port ${PORT} (${process.env.NODE_ENV})`);
    });
  })
  .catch(err => {
    console.error('[DB] Unable to connect to database:', err.message);
    process.exit(1);
  });

module.exports = { app, io };
