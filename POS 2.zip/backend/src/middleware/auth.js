// ============================================================
//  Auth Middleware — JWT + Role-Based Access Control
// ============================================================
const jwt = require('jsonwebtoken');
const { User } = require('../models');

// ── Permissions matrix ────────────────────────────────────
const PERMISSIONS = {
  admin: ['*'],                       // all access
  manager: [
    'sales.read', 'sales.write', 'sales.refund',
    'products.read', 'products.write',
    'inventory.read', 'inventory.write',
    'inventory.adjustment', 'inventory.transfer',
    'purchases.read', 'purchases.write', 'purchases.approve',
    'customers.read', 'customers.write',
    'expenses.read', 'expenses.write',
    'reports.read', 'reports.financial',
    'users.read',
  ],
  cashier: [
    'sales.read', 'sales.write',
    'products.read',
    'inventory.read',
    'customers.read', 'customers.write',
  ],
  stock_manager: [
    'products.read', 'products.write',
    'inventory.read', 'inventory.write',
    'inventory.adjustment', 'inventory.transfer',
    'purchases.read', 'purchases.write',
    'suppliers.read', 'suppliers.write',
  ],
};

// ── Authenticate ──────────────────────────────────────────
const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer '))
      return res.status(401).json({ error: 'No token provided' });

    const token = header.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findByPk(decoded.id, {
      attributes: ['id','name','email','role','branch_id','is_active','two_factor_enabled'],
    });

    if (!user || !user.is_active)
      return res.status(401).json({ error: 'Account is deactivated' });

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError')
      return res.status(401).json({ error: 'Token expired' });
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// ── Authorize by permission ───────────────────────────────
const authorize = (...requiredPermissions) => (req, res, next) => {
  const { role } = req.user;

  // Admin has all permissions
  if (PERMISSIONS[role]?.includes('*')) return next();

  const userPerms = PERMISSIONS[role] || [];
  const hasAll = requiredPermissions.every(p => userPerms.includes(p));

  if (!hasAll)
    return res.status(403).json({ error: 'Insufficient permissions' });

  next();
};

// ── Authorize by role ─────────────────────────────────────
const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ error: 'Access denied for your role' });
  next();
};

// ── Admin only shortcut ───────────────────────────────────
const adminOnly = requireRole('admin');
const adminOrManager = requireRole('admin', 'manager');

module.exports = { authenticate, authorize, requireRole, adminOnly, adminOrManager, PERMISSIONS };
