// ============================================================
//  Audit Middleware — records all system actions
// ============================================================
const { AuditLog } = require('../models');

const audit = (module, action, getDescription) => async (req, res, next) => {
  const originalJson = res.json.bind(res);

  res.json = async (body) => {
    // Only log successful mutations
    if (res.statusCode >= 200 && res.statusCode < 300) {
      try {
        const description = typeof getDescription === 'function'
          ? getDescription(req, body)
          : getDescription;

        await AuditLog.create({
          user_id:     req.user?.id || null,
          action,
          module,
          description: description || `${action} on ${module}`,
          ip_address:  req.ip || req.connection?.remoteAddress,
          new_values:  body?.data || null,
        });
      } catch (err) {
        console.error('[AUDIT] Failed to write audit log:', err.message);
      }
    }
    return originalJson(body);
  };
  next();
};

// Convenience wrappers
const auditLogin    = audit('auth',      'LOGIN',    (req) => `User ${req.body.email} logged in`);
const auditSale     = audit('sales',     'SALE',     (req, res) => `Sale ${res?.data?.receipt_number}`);
const auditProduct  = audit('products',  'PRODUCT',  (req) => `Product: ${req.body.name}`);
const auditStock    = audit('inventory', 'STOCK_ADJ',(req) => `Adjustment by ${req.user?.name}`);

module.exports = { audit, auditLogin, auditSale, auditProduct, auditStock };
