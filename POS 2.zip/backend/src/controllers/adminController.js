// ============================================================
//  Customer Controller
// ============================================================
const { Op } = require('sequelize');
const bcrypt = require('bcryptjs');
const { Customer, CreditPayment, Sale, User, Setting, AuditLog, Branch } = require('../models');
const { sequelize } = require('../config/database');

// ── Customers ─────────────────────────────────────────────
exports.listCustomers = async (req, res) => {
  try {
    const { search, has_credit, page = 1, limit = 50 } = req.query;
    const where = {};
    if (search) {
      where[Op.or] = [
        { name:  { [Op.like]: `%${search}%` } },
        { phone: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
      ];
    }
    if (has_credit === 'true') where.outstanding_balance = { [Op.gt]: 0 };
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await Customer.findAndCountAll({
      where, limit: parseInt(limit), offset, order: [['name','ASC']],
    });
    res.json({ success: true, data: rows, total: count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createCustomer = async (req, res) => {
  try {
    const customer = await Customer.create(req.body);
    res.status(201).json({ success: true, data: customer });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateCustomer = async (req, res) => {
  try {
    const customer = await Customer.findByPk(req.params.id);
    if (!customer) return res.status(404).json({ error: 'Customer not found' });
    await customer.update(req.body);
    res.json({ success: true, data: customer });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getCustomerStatement = async (req, res) => {
  try {
    const { id } = req.params;
    const { from, to } = req.query;
    const customer = await Customer.findByPk(id);
    if (!customer) return res.status(404).json({ error: 'Customer not found' });

    const saleWhere = { customer_id: id, status: { [Op.in]: ['completed','pending'] } };
    if (from) saleWhere.created_at = { [Op.gte]: new Date(from + 'T00:00:00') };
    if (to)   saleWhere.created_at = { ...saleWhere.created_at, [Op.lte]: new Date(to + 'T23:59:59') };

    const sales = await Sale.findAll({
      where: saleWhere, order: [['created_at','ASC']],
      attributes: ['id','receipt_number','total','credit_amount','amount_paid','created_at','status'],
    });

    const payments = await CreditPayment.findAll({
      where: { customer_id: id,
        ...(from ? { created_at: { [Op.gte]: new Date(from + 'T00:00:00') } } : {}),
      },
      order: [['created_at','ASC']],
    });

    res.json({ success: true, data: { customer, sales, payments } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.recordCreditPayment = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { customer_id, sale_id, amount, payment_method, reference, notes } = req.body;
    const customer = await Customer.findByPk(customer_id, { transaction: t, lock: true });
    if (!customer) throw new Error('Customer not found');

    const paid = parseFloat(amount);
    if (paid <= 0 || paid > parseFloat(customer.outstanding_balance))
      throw new Error('Invalid payment amount');

    await CreditPayment.create({
      customer_id, sale_id: sale_id || null, amount: paid,
      payment_method, reference, notes, received_by: req.user.id,
    }, { transaction: t });

    await customer.update({
      outstanding_balance: Math.max(0, parseFloat(customer.outstanding_balance) - paid),
    }, { transaction: t });

    await t.commit();
    res.status(201).json({ success: true, message: `Payment of TZS ${paid.toLocaleString()} recorded` });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ============================================================
//  Expense Controller
// ============================================================
exports.listExpenses = async (req, res) => {
  try {
    const { branch_id, category, from, to, page = 1, limit = 50 } = req.query;
    const where = {};
    if (branch_id) where.branch_id = branch_id;
    if (category)  where.category  = category;
    if (from) where.expense_date = { [Op.gte]: from };
    if (to)   where.expense_date = { ...where.expense_date, [Op.lte]: to };

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await require('../models').Expense.findAndCountAll({
      where,
      include: [
        { model: Branch, as: 'branch', attributes: ['id','name'] },
        { model: User, as: 'recorded_by_user', attributes: ['id','name'] },
      ],
      limit: parseInt(limit), offset, order: [['expense_date','DESC']],
    });

    const [totals] = await require('../models').Expense.findAll({
      where, attributes: [[sequelize.fn('SUM', sequelize.col('amount')), 'total']], raw: true,
    });

    res.json({ success: true, data: rows, total: count, total_amount: totals.total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createExpense = async (req, res) => {
  try {
    const expense = await require('../models').Expense.create({
      ...req.body, recorded_by: req.user.id,
    });
    res.status(201).json({ success: true, data: expense });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteExpense = async (req, res) => {
  try {
    const expense = await require('../models').Expense.findByPk(req.params.id);
    if (!expense) return res.status(404).json({ error: 'Expense not found' });
    await expense.destroy();
    res.json({ success: true, message: 'Expense deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ============================================================
//  Settings Controller
// ============================================================
exports.getSettings = async (req, res) => {
  try {
    const settings = await Setting.findAll();
    const obj = Object.fromEntries(settings.map(s => [s.key, s.value]));
    res.json({ success: true, data: obj });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateSettings = async (req, res) => {
  try {
    const updates = req.body;
    for (const [key, value] of Object.entries(updates)) {
      await Setting.upsert({ key, value });
    }
    await AuditLog.create({
      user_id: req.user.id, action: 'UPDATE_SETTINGS', module: 'settings',
      description: `Settings updated: ${Object.keys(updates).join(', ')}`,
      ip_address: req.ip, new_values: updates,
    });
    res.json({ success: true, message: 'Settings updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ============================================================
//  User Controller
// ============================================================
exports.listUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ['password','two_factor_secret'] },
      include: [{ model: Branch, as: 'branch', attributes: ['id','name'] }],
      order: [['name','ASC']],
    });
    res.json({ success: true, data: users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { name, email, password, role, branch_id, phone } = req.body;
    const hashed = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email: email.toLowerCase(), password: hashed, role, branch_id, phone });

    await AuditLog.create({
      user_id: req.user.id, action: 'CREATE_USER', module: 'users',
      description: `Created user: ${name} (${role})`, ip_address: req.ip,
    });

    const { password: _, two_factor_secret, ...safe } = user.toJSON();
    res.status(201).json({ success: true, data: safe });
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError')
      return res.status(400).json({ error: 'Email already exists' });
    res.status(400).json({ error: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const updates = { ...req.body };
    if (updates.password) updates.password = await bcrypt.hash(updates.password, 12);

    await user.update(updates);
    const { password: _, two_factor_secret, ...safe } = user.toJSON();
    res.json({ success: true, data: safe });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.toggleUser = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user.id === req.user.id) return res.status(400).json({ error: 'Cannot deactivate yourself' });
    await user.update({ is_active: !user.is_active });
    res.json({ success: true, message: `User ${user.is_active ? 'activated' : 'deactivated'}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.listBranches = async (req, res) => {
  try {
    const branches = await Branch.findAll({ where: { is_active: true }, order: [['name','ASC']] });
    res.json({ success: true, data: branches });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createBranch = async (req, res) => {
  try {
    const branch = await Branch.create(req.body);
    res.status(201).json({ success: true, data: branch });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getAuditLogs = async (req, res) => {
  try {
    const { module, user_id, from, to, page = 1, limit = 100 } = req.query;
    const where = {};
    if (module)  where.module  = module;
    if (user_id) where.user_id = user_id;
    if (from || to) {
      where.created_at = {};
      if (from) where.created_at[Op.gte] = new Date(from + 'T00:00:00');
      if (to)   where.created_at[Op.lte] = new Date(to   + 'T23:59:59');
    }
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await AuditLog.findAndCountAll({
      where,
      include: [{ model: User, as: 'user', attributes: ['id','name','role'],
        foreignKey: 'user_id' }],
      limit: parseInt(limit), offset, order: [['created_at','DESC']],
    });
    res.json({ success: true, data: rows, total: count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Attach User model for AuditLog include
AuditLog.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
