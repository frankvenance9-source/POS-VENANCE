// ============================================================
//  Auth Controller
// ============================================================
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const speakeasy = require('speakeasy');
const qrcode   = require('qrcode');
const { User, AuditLog, Setting } = require('../models');

const signToken = (user) =>
  jwt.sign(
    { id: user.id, role: user.role, branch_id: user.branch_id },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

// ── Login ─────────────────────────────────────────────────
exports.login = async (req, res) => {
  try {
    const { email, password, totp_code } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required' });

    const user = await User.findOne({ where: { email: email.toLowerCase() } });
    if (!user || !user.is_active)
      return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid)
      return res.status(401).json({ error: 'Invalid credentials' });

    // 2FA check
    if (user.two_factor_enabled) {
      if (!totp_code)
        return res.status(200).json({ requires_2fa: true });
      const verified = speakeasy.totp.verify({
        secret: user.two_factor_secret,
        encoding: 'base32',
        token: totp_code,
        window: 1,
      });
      if (!verified)
        return res.status(401).json({ error: 'Invalid 2FA code' });
    }

    await user.update({ last_login: new Date() });

    const token = signToken(user);

    // Audit
    await AuditLog.create({
      user_id: user.id, action: 'LOGIN', module: 'auth',
      description: `User ${user.name} logged in`,
      ip_address: req.ip,
    });

    res.json({
      success: true,
      token,
      user: {
        id: user.id, name: user.name, email: user.email,
        role: user.role, branch_id: user.branch_id,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
};

// ── Get current user ──────────────────────────────────────
exports.me = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password','two_factor_secret'] },
    });
    res.json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Change password ───────────────────────────────────────
exports.changePassword = async (req, res) => {
  try {
    const { current_password, new_password } = req.body;
    const user = await User.findByPk(req.user.id);

    const valid = await bcrypt.compare(current_password, user.password);
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect' });
    if (new_password.length < 8)
      return res.status(400).json({ error: 'Password must be at least 8 characters' });

    const hashed = await bcrypt.hash(new_password, 12);
    await user.update({ password: hashed });

    await AuditLog.create({
      user_id: req.user.id, action: 'CHANGE_PASSWORD', module: 'auth',
      description: 'Password changed', ip_address: req.ip,
    });

    res.json({ success: true, message: 'Password changed successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Setup 2FA ─────────────────────────────────────────────
exports.setup2FA = async (req, res) => {
  try {
    const shopName = (await Setting.findOne({ where: { key: 'shop_name' } }))?.value || 'POS System';
    const user = await User.findByPk(req.user.id);

    const secret = speakeasy.generateSecret({
      name: `${shopName} (${user.email})`,
      issuer: shopName,
    });

    await user.update({ two_factor_secret: secret.base32 });

    const qr = await qrcode.toDataURL(secret.otpauth_url);
    res.json({ success: true, data: { secret: secret.base32, qr_code: qr } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Verify & enable 2FA ───────────────────────────────────
exports.enable2FA = async (req, res) => {
  try {
    const { totp_code } = req.body;
    const user = await User.findByPk(req.user.id);

    const verified = speakeasy.totp.verify({
      secret: user.two_factor_secret,
      encoding: 'base32',
      token: totp_code,
      window: 1,
    });
    if (!verified) return res.status(400).json({ error: 'Invalid TOTP code' });

    await user.update({ two_factor_enabled: true });
    res.json({ success: true, message: '2FA enabled successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Disable 2FA ───────────────────────────────────────────
exports.disable2FA = async (req, res) => {
  try {
    const { password } = req.body;
    const user = await User.findByPk(req.user.id);

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid password' });

    await user.update({ two_factor_enabled: false, two_factor_secret: null });
    res.json({ success: true, message: '2FA disabled' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
