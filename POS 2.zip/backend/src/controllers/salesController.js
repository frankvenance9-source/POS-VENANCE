// ============================================================
//  Sales Controller — POS Checkout & Sales Management
// ============================================================
const { sequelize } = require('../config/database');
const { Op } = require('sequelize');
const {
  Sale, SaleItem, Product, Customer, Inventory, PaymentDetail,
  CreditPayment, StockMovement, AuditLog, Setting, User,
} = require('../models');

// ── Generate receipt number ───────────────────────────────
async function generateReceiptNumber() {
  const prefix = (await Setting.findOne({ where: { key: 'invoice_prefix' } }))?.value || 'RCP';
  const today = new Date().toISOString().slice(0,10).replace(/-/g,'');
  const count = await Sale.count({
    where: { created_at: { [Op.gte]: new Date().setHours(0,0,0,0) } }
  });
  return `${prefix}-${today}-${String(count + 1).padStart(4,'0')}`;
}

// ── Create sale (main POS checkout) ──────────────────────
exports.create = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const {
      branch_id, customer_id, items, payments,
      discount = 0, tax_rate = 0, notes,
    } = req.body;

    if (!items?.length) throw new Error('Cart is empty');

    const cashier_id = req.user.id;
    let subtotal = 0, cost_total = 0;

    // Validate all items & stock
    const enrichedItems = [];
    for (const item of items) {
      const product = await Product.findByPk(item.product_id, { transaction: t, lock: true });
      if (!product || !product.is_active) throw new Error(`Product not found: ${item.product_id}`);

      const stock = await Inventory.findOne({
        where: { product_id: item.product_id, branch_id },
        transaction: t, lock: true,
      });
      if (!stock || stock.quantity < item.quantity)
        throw new Error(`Insufficient stock for: ${product.name}`);

      const unit_price = parseFloat(item.unit_price || product.selling_price);
      const cost_price = parseFloat(product.cost_price);
      const itemDiscount = parseFloat(item.discount || 0);
      const qty = parseFloat(item.quantity);
      const total = (unit_price * qty) - itemDiscount;
      const profit = (unit_price - cost_price) * qty - itemDiscount;

      subtotal   += total;
      cost_total += cost_price * qty;

      enrichedItems.push({
        product_id: item.product_id, quantity: qty,
        unit_price, cost_price, discount: itemDiscount, total, profit,
      });
    }

    const discountAmt = parseFloat(discount);
    const taxAmt      = (subtotal - discountAmt) * (parseFloat(tax_rate) / 100);
    const total       = subtotal - discountAmt + taxAmt;
    const profit      = total - cost_total - discountAmt;

    // Determine primary payment method
    let paymentMethod = 'cash';
    let amountPaid = 0, creditAmount = 0;

    if (payments?.length === 1) {
      paymentMethod = payments[0].payment_method;
      amountPaid    = parseFloat(payments[0].amount);
    } else if (payments?.length > 1) {
      paymentMethod = 'mixed';
      payments.forEach(p => {
        amountPaid += parseFloat(p.amount);
        if (p.payment_method === 'credit') creditAmount += parseFloat(p.amount);
      });
    } else {
      amountPaid = total; // full cash
    }

    const changeAmount = Math.max(0, amountPaid - total - creditAmount);
    const receipt_number = await generateReceiptNumber();

    // Create sale record
    const sale = await Sale.create({
      receipt_number, branch_id, customer_id: customer_id || null, cashier_id,
      subtotal, discount: discountAmt, tax_amount: taxAmt,
      total, cost_total, profit,
      payment_method: paymentMethod, amount_paid: amountPaid,
      change_amount: changeAmount, credit_amount: creditAmount,
      status: 'completed', notes,
    }, { transaction: t });

    // Create sale items & deduct stock
    for (const item of enrichedItems) {
      await SaleItem.create({ sale_id: sale.id, ...item }, { transaction: t });

      // Deduct inventory
      const inv = await Inventory.findOne({
        where: { product_id: item.product_id, branch_id },
        transaction: t, lock: true,
      });
      const newQty = parseFloat(inv.quantity) - item.quantity;
      await inv.update({ quantity: newQty }, { transaction: t });

      // Stock movement record
      await StockMovement.create({
        product_id: item.product_id, branch_id,
        type: 'sale', quantity: -item.quantity,
        balance_after: newQty, unit_cost: item.cost_price,
        reference_id: sale.id, reference_type: 'sale',
        created_by: cashier_id,
      }, { transaction: t });
    }

    // Save payment split
    if (payments?.length) {
      for (const p of payments) {
        await PaymentDetail.create({
          sale_id: sale.id,
          payment_method: p.payment_method,
          amount: parseFloat(p.amount),
          reference: p.reference || null,
        }, { transaction: t });
      }
    }

    // Handle credit
    if (creditAmount > 0 && customer_id) {
      const customer = await Customer.findByPk(customer_id, { transaction: t });
      await customer.increment('outstanding_balance', { by: creditAmount, transaction: t });
    }

    // Update customer outstanding balance
    if (customer_id) {
      const customer = await Customer.findByPk(customer_id, { transaction: t });
      await customer.update({
        outstanding_balance: Math.max(0,
          parseFloat(customer.outstanding_balance) + creditAmount
        )
      }, { transaction: t });
    }

    await AuditLog.create({
      user_id: cashier_id, action: 'SALE', module: 'sales',
      description: `Sale ${receipt_number} — TZS ${total.toLocaleString()}`,
      ip_address: req.ip,
    }, { transaction: t });

    await t.commit();

    // Emit real-time update
    if (req.io) {
      req.io.to(`branch_${branch_id}`).emit('new_sale', {
        receipt_number, total, cashier: req.user.name,
      });
    }

    // Return full sale with items
    const completeSale = await Sale.findByPk(sale.id, {
      include: [
        { model: SaleItem, as: 'items', include: [{ model: Product, as: 'product', attributes: ['id','name','unit_of_measure'] }] },
        { model: Customer, as: 'customer', attributes: ['id','name','phone'] },
        { model: User, as: 'cashier', attributes: ['id','name'] },
        { model: PaymentDetail, as: 'payments' },
      ],
    });

    res.status(201).json({ success: true, data: completeSale });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── List sales ────────────────────────────────────────────
exports.list = async (req, res) => {
  try {
    const { branch_id, cashier_id, customer_id, from, to, status,
            payment_method, page = 1, limit = 50 } = req.query;
    const where = {};

    if (branch_id)      where.branch_id      = branch_id;
    if (cashier_id)     where.cashier_id     = cashier_id;
    if (customer_id)    where.customer_id    = customer_id;
    if (status)         where.status         = status;
    if (payment_method) where.payment_method = payment_method;
    if (from || to) {
      where.created_at = {};
      if (from) where.created_at[Op.gte] = new Date(from + 'T00:00:00');
      if (to)   where.created_at[Op.lte] = new Date(to   + 'T23:59:59');
    }

    // Non-admin/manager can only see own sales
    if (!['admin','manager'].includes(req.user.role)) {
      where.cashier_id = req.user.id;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await Sale.findAndCountAll({
      where,
      include: [
        { model: Customer, as: 'customer', attributes: ['id','name','phone'] },
        { model: User,     as: 'cashier',  attributes: ['id','name'] },
      ],
      limit: parseInt(limit), offset,
      order: [['created_at','DESC']],
    });

    // Totals for this filter
    const totals = await Sale.findAll({
      where, attributes: [
        [sequelize.fn('SUM', sequelize.col('total')),   'total_sales'],
        [sequelize.fn('SUM', sequelize.col('profit')),  'total_profit'],
        [sequelize.fn('SUM', sequelize.col('cost_total')), 'total_cost'],
        [sequelize.fn('COUNT', sequelize.col('id')),    'count'],
      ],
      raw: true,
    });

    res.json({
      success: true, data: rows, total: count,
      page: parseInt(page), limit: parseInt(limit),
      summary: totals[0],
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Get single sale ───────────────────────────────────────
exports.getOne = async (req, res) => {
  try {
    const sale = await Sale.findByPk(req.params.id, {
      include: [
        { model: SaleItem, as: 'items',
          include: [{ model: Product, as: 'product', attributes: ['id','name','unit_of_measure','barcode'] }] },
        { model: Customer, as: 'customer' },
        { model: User, as: 'cashier', attributes: ['id','name'] },
        { model: PaymentDetail, as: 'payments' },
      ],
    });
    if (!sale) return res.status(404).json({ error: 'Sale not found' });
    res.json({ success: true, data: sale });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Refund sale ───────────────────────────────────────────
exports.refund = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const sale = await Sale.findByPk(req.params.id, {
      include: [{ model: SaleItem, as: 'items' }],
      transaction: t,
    });
    if (!sale) throw new Error('Sale not found');
    if (sale.status === 'refunded') throw new Error('Sale already refunded');

    // Restore inventory
    for (const item of sale.items) {
      const inv = await Inventory.findOne({
        where: { product_id: item.product_id, branch_id: sale.branch_id },
        transaction: t, lock: true,
      });
      if (inv) {
        const newQty = parseFloat(inv.quantity) + parseFloat(item.quantity);
        await inv.update({ quantity: newQty }, { transaction: t });
        await StockMovement.create({
          product_id: item.product_id, branch_id: sale.branch_id,
          type: 'return', quantity: item.quantity, balance_after: newQty,
          reference_id: sale.id, reference_type: 'sale',
          created_by: req.user.id,
        }, { transaction: t });
      }
    }

    await sale.update({ status: 'refunded' }, { transaction: t });

    await AuditLog.create({
      user_id: req.user.id, action: 'REFUND', module: 'sales',
      description: `Refunded sale ${sale.receipt_number}`,
      ip_address: req.ip,
    }, { transaction: t });

    await t.commit();
    res.json({ success: true, message: 'Sale refunded successfully' });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Daily summary ─────────────────────────────────────────
exports.dailySummary = async (req, res) => {
  try {
    const { date = new Date().toISOString().slice(0,10), branch_id } = req.query;
    const where = {
      created_at: {
        [Op.gte]: new Date(date + 'T00:00:00'),
        [Op.lte]: new Date(date + 'T23:59:59'),
      },
      status: 'completed',
    };
    if (branch_id) where.branch_id = branch_id;

    const [summary] = await Sale.findAll({
      where, attributes: [
        [sequelize.fn('COUNT', sequelize.col('id')), 'transactions'],
        [sequelize.fn('SUM', sequelize.col('total')), 'revenue'],
        [sequelize.fn('SUM', sequelize.col('profit')), 'profit'],
        [sequelize.fn('SUM', sequelize.col('cost_total')), 'cost'],
        [sequelize.fn('SUM', sequelize.col('discount')), 'discounts'],
      ],
      raw: true,
    });

    // By payment method
    const byPayment = await Sale.findAll({
      where, attributes: [
        'payment_method',
        [sequelize.fn('SUM', sequelize.col('total')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['payment_method'],
      raw: true,
    });

    res.json({ success: true, data: { summary, by_payment: byPayment, date } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Sync offline sales ────────────────────────────────────
exports.syncOffline = async (req, res) => {
  const results = { success: [], failed: [] };
  for (const saleData of req.body.sales || []) {
    try {
      // Check if already synced
      const exists = await Sale.findOne({ where: { receipt_number: saleData.receipt_number } });
      if (exists) { results.success.push(saleData.receipt_number); continue; }

      await exports.create({ ...req, body: saleData }, {
        status: () => ({ json: (d) => results.success.push(d?.data?.receipt_number) }),
        json:   (d) => { if (d.success) results.success.push(d.data?.receipt_number); else results.failed.push(saleData.receipt_number); },
        io: req.io,
      });
    } catch (err) {
      results.failed.push({ id: saleData.receipt_number, error: err.message });
    }
  }
  res.json({ success: true, data: results });
};
