// ============================================================
//  Purchase Controller — POs & GRNs
// ============================================================
const { sequelize } = require('../config/database');
const { Op } = require('sequelize');
const {
  PurchaseOrder, PurchaseOrderItem, GRN, GRNItem, Supplier, Product,
  Branch, Inventory, StockMovement, AuditLog, Setting, User,
} = require('../models');

async function nextNumber(prefix_key, model, field) {
  const prefix = (await Setting.findOne({ where: { key: prefix_key } }))?.value || prefix_key.slice(0,3).toUpperCase();
  const today  = new Date().toISOString().slice(0,10).replace(/-/g,'');
  const count  = await model.count({ where: { [field]: { [Op.like]: `%${today}%` } } });
  return `${prefix}-${today}-${String(count + 1).padStart(4,'0')}`;
}

// ── Create PO ─────────────────────────────────────────────
exports.createPO = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { supplier_id, branch_id, items, expected_date, notes } = req.body;

    let subtotal = 0;
    const enriched = items.map(i => {
      const total = parseFloat(i.unit_cost) * parseFloat(i.quantity_ordered);
      subtotal += total;
      return { ...i, total };
    });

    const po_number = await nextNumber('po_prefix', PurchaseOrder, 'po_number');
    const po = await PurchaseOrder.create({
      po_number, supplier_id, branch_id, subtotal, total: subtotal,
      expected_date, notes, ordered_by: req.user.id, status: 'draft',
    }, { transaction: t });

    for (const item of enriched) {
      await PurchaseOrderItem.create({
        po_id: po.id, product_id: item.product_id,
        quantity_ordered: item.quantity_ordered, quantity_received: 0,
        unit_cost: item.unit_cost, total: item.total,
      }, { transaction: t });
    }

    await AuditLog.create({
      user_id: req.user.id, action: 'CREATE_PO', module: 'purchases',
      description: `PO ${po_number} created — TZS ${subtotal.toLocaleString()}`,
      ip_address: req.ip,
    }, { transaction: t });

    await t.commit();
    res.status(201).json({ success: true, data: po });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── List POs ──────────────────────────────────────────────
exports.listPOs = async (req, res) => {
  try {
    const { supplier_id, branch_id, status, from, to, page = 1, limit = 20 } = req.query;
    const where = {};
    if (supplier_id) where.supplier_id = supplier_id;
    if (branch_id)   where.branch_id   = branch_id;
    if (status)      where.status      = status;
    if (from || to) {
      where.created_at = {};
      if (from) where.created_at[Op.gte] = new Date(from + 'T00:00:00');
      if (to)   where.created_at[Op.lte] = new Date(to   + 'T23:59:59');
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await PurchaseOrder.findAndCountAll({
      where,
      include: [
        { model: Supplier, as: 'supplier', attributes: ['id','name'] },
        { model: Branch,   as: 'branch',   attributes: ['id','name'] },
        { model: User,     as: 'ordered_by', attributes: ['id','name'],
          foreignKey: 'ordered_by' },
      ],
      limit: parseInt(limit), offset,
      order: [['created_at','DESC']],
    });

    res.json({ success: true, data: rows, total: count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Get PO detail ─────────────────────────────────────────
exports.getPO = async (req, res) => {
  try {
    const po = await PurchaseOrder.findByPk(req.params.id, {
      include: [
        { model: Supplier, as: 'supplier' },
        { model: Branch,   as: 'branch' },
        { model: PurchaseOrderItem, as: 'items',
          include: [{ model: Product, as: 'product', attributes: ['id','name','barcode','unit_of_measure'] }] },
      ],
    });
    if (!po) return res.status(404).json({ error: 'Purchase order not found' });
    res.json({ success: true, data: po });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Create GRN ────────────────────────────────────────────
exports.createGRN = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { po_id, supplier_id, branch_id, items, notes } = req.body;

    const grn_number = await nextNumber('grn_prefix', GRN, 'grn_number');
    let total_cost = 0;

    const grn = await GRN.create({
      grn_number, po_id: po_id || null, supplier_id, branch_id,
      status: 'draft', notes, received_by: req.user.id,
    }, { transaction: t });

    for (const item of items) {
      const qty   = parseFloat(item.quantity_received);
      const cost  = parseFloat(item.unit_cost);
      const total = qty * cost;
      total_cost += total;

      await GRNItem.create({
        grn_id: grn.id, product_id: item.product_id,
        quantity_received: qty, unit_cost: cost, total,
      }, { transaction: t });
    }

    await grn.update({ total_cost }, { transaction: t });
    await t.commit();
    res.status(201).json({ success: true, data: grn });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Confirm GRN — updates inventory ──────────────────────
exports.confirmGRN = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const grn = await GRN.findByPk(req.params.id, {
      include: [{ model: GRNItem, as: 'items' }],
      transaction: t,
    });
    if (!grn) throw new Error('GRN not found');
    if (grn.status === 'confirmed') throw new Error('GRN already confirmed');

    for (const item of grn.items) {
      // Upsert inventory
      const [inv] = await Inventory.findOrCreate({
        where: { product_id: item.product_id, branch_id: grn.branch_id },
        defaults: { quantity: 0 }, transaction: t,
      });
      const newQty = parseFloat(inv.quantity) + parseFloat(item.quantity_received);
      await inv.update({ quantity: newQty }, { transaction: t });

      // Update product cost price (weighted average)
      const prod = await Product.findByPk(item.product_id, { transaction: t });
      const oldCost = parseFloat(prod.cost_price);
      const oldQty  = parseFloat(inv.quantity) - parseFloat(item.quantity_received);
      const weightedCost = oldQty > 0
        ? ((oldCost * oldQty) + (parseFloat(item.unit_cost) * parseFloat(item.quantity_received))) / newQty
        : parseFloat(item.unit_cost);
      await prod.update({ cost_price: weightedCost }, { transaction: t });

      // Stock movement
      await StockMovement.create({
        product_id: item.product_id, branch_id: grn.branch_id,
        type: 'purchase', quantity: item.quantity_received,
        balance_after: newQty, unit_cost: item.unit_cost,
        reference_id: grn.id, reference_type: 'grn',
        created_by: req.user.id,
      }, { transaction: t });
    }

    await grn.update({ status: 'confirmed', received_at: new Date() }, { transaction: t });

    // Update PO status if linked
    if (grn.po_id) {
      const po = await PurchaseOrder.findByPk(grn.po_id, {
        include: [{ model: PurchaseOrderItem, as: 'items' }],
        transaction: t,
      });
      if (po) {
        const allReceived = po.items.every(item =>
          parseFloat(item.quantity_received) >= parseFloat(item.quantity_ordered)
        );
        await po.update({ status: allReceived ? 'received' : 'partial' }, { transaction: t });
      }
    }

    await AuditLog.create({
      user_id: req.user.id, action: 'CONFIRM_GRN', module: 'purchases',
      description: `GRN ${grn.grn_number} confirmed — stock updated`,
      ip_address: req.ip,
    }, { transaction: t });

    await t.commit();
    res.json({ success: true, message: 'GRN confirmed and inventory updated' });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Supplier CRUD ─────────────────────────────────────────
exports.listSuppliers = async (req, res) => {
  try {
    const { search, active } = req.query;
    const where = {};
    if (search) where.name = { [Op.like]: `%${search}%` };
    if (active !== undefined) where.is_active = active === 'true';
    const suppliers = await Supplier.findAll({ where, order: [['name','ASC']] });
    res.json({ success: true, data: suppliers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createSupplier = async (req, res) => {
  try {
    const supplier = await Supplier.create(req.body);
    res.status(201).json({ success: true, data: supplier });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateSupplier = async (req, res) => {
  try {
    const supplier = await Supplier.findByPk(req.params.id);
    if (!supplier) return res.status(404).json({ error: 'Supplier not found' });
    await supplier.update(req.body);
    res.json({ success: true, data: supplier });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
