// ============================================================
//  Reports Controller — Analytics, P&L, Exports
// ============================================================
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const {
  Sale, SaleItem, Product, Category, Customer, Expense, Inventory,
  StockMovement, Branch, Setting, User,
} = require('../models');

const currency = (n) => `TZS ${parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 2 })}`;

async function getShopSettings() {
  const settings = await Setting.findAll({ raw: true });
  return Object.fromEntries(settings.map(s => [s.key, s.value]));
}

// ── Dashboard KPIs ────────────────────────────────────────
exports.dashboard = async (req, res) => {
  try {
    const { branch_id } = req.query;
    const today = new Date().toISOString().slice(0,10);
    const month_start = today.slice(0,8) + '01';

    const makeWhere = (from, to) => {
      const w = {
        status: 'completed',
        created_at: {
          [Op.gte]: new Date(from + 'T00:00:00'),
          [Op.lte]: new Date(to   + 'T23:59:59'),
        },
      };
      if (branch_id) w.branch_id = branch_id;
      return w;
    };

    const [todaySales]  = await Sale.findAll({ where: makeWhere(today, today),
      attributes: [
        [sequelize.fn('SUM', sequelize.col('total')),  'revenue'],
        [sequelize.fn('SUM', sequelize.col('profit')), 'profit'],
        [sequelize.fn('COUNT', sequelize.col('id')),   'transactions'],
      ], raw: true });

    const [monthSales] = await Sale.findAll({ where: makeWhere(month_start, today),
      attributes: [
        [sequelize.fn('SUM', sequelize.col('total')),  'revenue'],
        [sequelize.fn('SUM', sequelize.col('profit')), 'profit'],
        [sequelize.fn('COUNT', sequelize.col('id')),   'transactions'],
      ], raw: true });

    // Top 5 products today
    const topProducts = await SaleItem.findAll({
      include: [
        { model: Sale, as: 'sale', where: makeWhere(today, today), attributes: [] },
        { model: Product, as: 'product', attributes: ['id','name'] },
      ],
      attributes: [
        'product_id',
        [sequelize.fn('SUM', sequelize.col('SaleItem.quantity')), 'qty_sold'],
        [sequelize.fn('SUM', sequelize.col('SaleItem.total')),    'revenue'],
        [sequelize.fn('SUM', sequelize.col('SaleItem.profit')),   'profit'],
      ],
      group: ['product_id','product.id'],
      order: [[sequelize.fn('SUM', sequelize.col('SaleItem.total')), 'DESC']],
      limit: 5,
    });

    // Low stock alerts
    const invWhere = {};
    if (branch_id) invWhere.branch_id = branch_id;
    const lowStock = await Inventory.findAll({
      where: invWhere,
      include: [{ model: Product, as: 'product',
        where: { is_active: true }, attributes: ['id','name','reorder_level','unit_of_measure'] }],
    }).then(items => items.filter(i =>
      parseFloat(i.quantity) <= parseFloat(i.product.reorder_level || 0)
    ));

    // Monthly trend (last 6 months)
    const trend = await Sale.findAll({
      where: {
        status: 'completed',
        created_at: { [Op.gte]: new Date(Date.now() - 6 * 30 * 24 * 3600 * 1000) },
        ...(branch_id ? { branch_id } : {}),
      },
      attributes: [
        [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m'), 'month'],
        [sequelize.fn('SUM', sequelize.col('total')),  'revenue'],
        [sequelize.fn('SUM', sequelize.col('profit')), 'profit'],
        [sequelize.fn('COUNT', sequelize.col('id')),   'transactions'],
      ],
      group: [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m')],
      order: [[sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m'), 'ASC']],
      raw: true,
    });

    res.json({
      success: true,
      data: {
        today:       todaySales,
        month:       monthSales,
        top_products: topProducts,
        low_stock:   lowStock,
        trend,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Sales report ──────────────────────────────────────────
exports.sales = async (req, res) => {
  try {
    const { from, to, branch_id, group_by = 'day' } = req.query;
    const where = { status: 'completed' };
    if (branch_id) where.branch_id = branch_id;
    if (from) where.created_at = { ...where.created_at, [Op.gte]: new Date(from + 'T00:00:00') };
    if (to)   where.created_at = { ...where.created_at, [Op.lte]: new Date(to   + 'T23:59:59') };

    const format = group_by === 'month' ? '%Y-%m' : group_by === 'year' ? '%Y' : '%Y-%m-%d';
    const data = await Sale.findAll({
      where,
      attributes: [
        [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), format), 'period'],
        [sequelize.fn('COUNT', sequelize.col('id')),              'transactions'],
        [sequelize.fn('SUM', sequelize.col('total')),             'revenue'],
        [sequelize.fn('SUM', sequelize.col('profit')),            'profit'],
        [sequelize.fn('SUM', sequelize.col('discount')),          'discounts'],
        [sequelize.fn('SUM', sequelize.col('cost_total')),        'cost'],
      ],
      group: [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), format)],
      order: [[sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), format), 'ASC']],
      raw: true,
    });

    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Profit & Loss statement ───────────────────────────────
exports.profitLoss = async (req, res) => {
  try {
    const { from, to, branch_id } = req.query;
    const saleWhere = { status: 'completed' };
    const expWhere  = {};
    if (branch_id) { saleWhere.branch_id = branch_id; expWhere.branch_id = branch_id; }
    if (from) {
      saleWhere.created_at = { [Op.gte]: new Date(from + 'T00:00:00') };
      expWhere.expense_date = { [Op.gte]: from };
    }
    if (to) {
      saleWhere.created_at = { ...saleWhere.created_at, [Op.lte]: new Date(to + 'T23:59:59') };
      expWhere.expense_date = { ...expWhere.expense_date, [Op.lte]: to };
    }

    const [sales] = await Sale.findAll({
      where: saleWhere,
      attributes: [
        [sequelize.fn('SUM', sequelize.col('total')),      'revenue'],
        [sequelize.fn('SUM', sequelize.col('cost_total')), 'cogs'],
        [sequelize.fn('SUM', sequelize.col('profit')),     'gross_profit'],
        [sequelize.fn('SUM', sequelize.col('discount')),   'discounts'],
      ],
      raw: true,
    });

    const [expenses] = await Expense.findAll({
      where: expWhere,
      attributes: [
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
      ],
      raw: true,
    });

    const expByCategory = await Expense.findAll({
      where: expWhere,
      attributes: [
        'category',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
      ],
      group: ['category'],
      raw: true,
    });

    const revenue     = parseFloat(sales.revenue || 0);
    const cogs        = parseFloat(sales.cogs || 0);
    const grossProfit = parseFloat(sales.gross_profit || 0);
    const totalExpenses = parseFloat(expenses.total || 0);
    const netProfit   = grossProfit - totalExpenses;

    res.json({
      success: true,
      data: {
        period: { from, to },
        revenue, cogs, gross_profit: grossProfit,
        gross_margin: revenue ? ((grossProfit / revenue) * 100).toFixed(2) : 0,
        expenses: totalExpenses, expenses_by_category: expByCategory,
        net_profit: netProfit,
        net_margin: revenue ? ((netProfit / revenue) * 100).toFixed(2) : 0,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Top products report ───────────────────────────────────
exports.topProducts = async (req, res) => {
  try {
    const { from, to, branch_id, limit = 20, sort_by = 'revenue' } = req.query;
    const saleWhere = { status: 'completed' };
    if (branch_id) saleWhere.branch_id = branch_id;
    if (from) saleWhere.created_at = { [Op.gte]: new Date(from + 'T00:00:00') };
    if (to)   saleWhere.created_at = { ...saleWhere.created_at, [Op.lte]: new Date(to + 'T23:59:59') };

    const sortCol = sort_by === 'profit' ? 'SaleItem.profit' : sort_by === 'qty' ? 'SaleItem.quantity' : 'SaleItem.total';

    const data = await SaleItem.findAll({
      include: [
        { model: Sale, as: 'sale', where: saleWhere, attributes: [] },
        { model: Product, as: 'product', attributes: ['id','name','unit_of_measure','barcode'] },
      ],
      attributes: [
        'product_id',
        [sequelize.fn('SUM', sequelize.col('SaleItem.quantity')), 'qty_sold'],
        [sequelize.fn('SUM', sequelize.col('SaleItem.total')),    'revenue'],
        [sequelize.fn('SUM', sequelize.col('SaleItem.profit')),   'profit'],
        [sequelize.fn('COUNT', sequelize.col('SaleItem.sale_id')), 'transactions'],
      ],
      group: ['product_id', 'product.id'],
      order: [[sequelize.fn('SUM', sequelize.col(sortCol)), 'DESC']],
      limit: parseInt(limit),
    });

    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Inventory valuation report ────────────────────────────
exports.inventoryValuation = async (req, res) => {
  try {
    const { branch_id } = req.query;
    const where = {};
    if (branch_id) where.branch_id = branch_id;

    const items = await Inventory.findAll({
      where,
      include: [
        { model: Product, as: 'product',
          where: { is_active: true },
          attributes: ['id','name','cost_price','selling_price','unit_of_measure','barcode'] },
        { model: Branch, as: 'branch', attributes: ['id','name'] },
      ],
    });

    const data = items.map(i => ({
      product_id:    i.product.id,
      product_name:  i.product.name,
      barcode:       i.product.barcode,
      branch:        i.branch.name,
      quantity:      parseFloat(i.quantity),
      cost_price:    parseFloat(i.product.cost_price),
      selling_price: parseFloat(i.product.selling_price),
      cost_value:    parseFloat(i.quantity) * parseFloat(i.product.cost_price),
      retail_value:  parseFloat(i.quantity) * parseFloat(i.product.selling_price),
    }));

    const totals = data.reduce((acc, r) => ({
      cost_value:   acc.cost_value   + r.cost_value,
      retail_value: acc.retail_value + r.retail_value,
      potential_profit: (acc.retail_value + r.retail_value) - (acc.cost_value + r.cost_value),
    }), { cost_value: 0, retail_value: 0, potential_profit: 0 });

    res.json({ success: true, data, totals });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Export to Excel ───────────────────────────────────────
exports.exportExcel = async (req, res) => {
  try {
    const { type, from, to, branch_id } = req.query;
    const shop = await getShopSettings();

    const wb = new ExcelJS.Workbook();
    wb.creator = shop.shop_name;
    wb.created  = new Date();

    const ws = wb.addWorksheet(type === 'pl' ? 'Profit & Loss' : 'Sales Report');

    // Header styles
    const headerStyle = {
      font: { bold: true, color: { argb: 'FFFFFFFF' } },
      fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E40AF' } },
      alignment: { horizontal: 'center', vertical: 'middle' },
      border: { bottom: { style: 'thin' } },
    };

    const saleWhere = { status: 'completed' };
    if (branch_id) saleWhere.branch_id = branch_id;
    if (from) saleWhere.created_at = { [Op.gte]: new Date(from + 'T00:00:00') };
    if (to)   saleWhere.created_at = { ...saleWhere.created_at, [Op.lte]: new Date(to + 'T23:59:59') };

    if (type === 'sales') {
      ws.columns = [
        { header: 'Receipt #',   key: 'receipt', width: 18 },
        { header: 'Date',        key: 'date',    width: 20 },
        { header: 'Cashier',     key: 'cashier', width: 18 },
        { header: 'Customer',    key: 'customer',width: 18 },
        { header: 'Total (TZS)', key: 'total',   width: 18 },
        { header: 'Profit(TZS)',  key: 'profit',  width: 18 },
        { header: 'Payment',     key: 'payment', width: 15 },
        { header: 'Status',      key: 'status',  width: 12 },
      ];
      ws.getRow(1).eachCell(c => Object.assign(c, headerStyle));

      const sales = await Sale.findAll({
        where: saleWhere,
        include: [
          { model: User,     as: 'cashier',  attributes: ['name'] },
          { model: Customer, as: 'customer', attributes: ['name'] },
        ],
        order: [['created_at','DESC']],
      });

      sales.forEach(s => {
        ws.addRow({
          receipt:  s.receipt_number,
          date:     s.created_at.toLocaleString('en-TZ'),
          cashier:  s.cashier?.name,
          customer: s.customer?.name || 'Walk-in',
          total:    parseFloat(s.total),
          profit:   parseFloat(s.profit),
          payment:  s.payment_method,
          status:   s.status,
        });
      });
    }

    // Column total row
    const lastRow = ws.rowCount + 1;
    ws.addRow(['TOTAL', '', '', '',
      { formula: `SUM(E2:E${lastRow-1})` },
      { formula: `SUM(F2:F${lastRow-1})` },
    ]);
    ws.getRow(lastRow).font = { bold: true };

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=report-${type}-${Date.now()}.xlsx`);
    await wb.xlsx.write(res);
    res.end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Export to PDF ─────────────────────────────────────────
exports.exportPDF = async (req, res) => {
  try {
    const { type, from, to, branch_id } = req.query;
    const shop = await getShopSettings();

    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=report-${type}-${Date.now()}.pdf`);
    doc.pipe(res);

    // Header
    doc.fontSize(18).font('Helvetica-Bold').text(shop.shop_name, { align: 'center' });
    doc.fontSize(10).font('Helvetica').text(shop.shop_address || '', { align: 'center' });
    doc.moveDown();
    doc.fontSize(14).font('Helvetica-Bold')
       .text(`${type.toUpperCase()} REPORT — ${from || ''} to ${to || ''}`, { align: 'center' });
    doc.moveDown();

    // Content (simplified - add your full data here)
    doc.fontSize(10).font('Helvetica').text('Report generated at: ' + new Date().toLocaleString('en-TZ'));
    doc.moveDown();

    doc.end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
