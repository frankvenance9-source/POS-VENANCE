// ============================================================
//  Product Controller
// ============================================================
const bwipjs  = require('bwip-js');
const { Op }  = require('sequelize');
const { Product, Category, Supplier, Inventory, Branch, AuditLog } = require('../models');

// ── List products ─────────────────────────────────────────
exports.list = async (req, res) => {
  try {
    const { search, category_id, supplier_id, active, page = 1, limit = 50 } = req.query;
    const where = {};

    if (search) {
      where[Op.or] = [
        { name:    { [Op.like]: `%${search}%` } },
        { barcode: { [Op.like]: `%${search}%` } },
        { sku:     { [Op.like]: `%${search}%` } },
      ];
    }
    if (category_id) where.category_id = category_id;
    if (supplier_id) where.supplier_id = supplier_id;
    if (active !== undefined) where.is_active = active === 'true';

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows } = await Product.findAndCountAll({
      where,
      include: [
        { model: Category, as: 'category', attributes: ['id','name'] },
        { model: Supplier, as: 'supplier', attributes: ['id','name'] },
      ],
      limit: parseInt(limit),
      offset,
      order: [['name','ASC']],
    });

    res.json({ success: true, data: rows, total: count, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Get product by barcode (for POS scan) ─────────────────
exports.findByBarcode = async (req, res) => {
  try {
    const { barcode } = req.params;
    const product = await Product.findOne({
      where: { barcode, is_active: true },
      include: [
        { model: Category, as: 'category', attributes: ['id','name'] },
      ],
    });
    if (!product) return res.status(404).json({ error: 'Product not found' });

    // Get stock for the branch
    const branchId = req.query.branch_id || req.user.branch_id || 1;
    const stock = await Inventory.findOne({ where: { product_id: product.id, branch_id: branchId } });

    res.json({ success: true, data: { ...product.toJSON(), current_stock: stock?.quantity || 0 } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Create product ────────────────────────────────────────
exports.create = async (req, res) => {
  try {
    const {
      name, category_id, barcode, sku, cost_price, markup_percentage,
      unit_of_measure, supplier_id, reorder_level, description, barcode_type,
    } = req.body;

    // Auto-calculate selling price
    const cost   = parseFloat(cost_price) || 0;
    const markup = parseFloat(markup_percentage) || 30;
    const selling_price = cost + (cost * markup / 100);

    // Auto-generate barcode if not provided
    let finalBarcode = barcode;
    if (!finalBarcode) {
      const ts = Date.now().toString().slice(-10);
      finalBarcode = ts.padStart(13, '0');
    }

    // Auto-generate SKU if not provided
    let finalSku = sku;
    if (!finalSku) {
      finalSku = 'SKU-' + Date.now().toString(36).toUpperCase();
    }

    const product = await Product.create({
      name, category_id, barcode: finalBarcode, sku: finalSku,
      cost_price: cost, selling_price, markup_percentage: markup,
      unit_of_measure, supplier_id, reorder_level, description,
      barcode_type: barcode_type || 'CODE128',
      image_url: req.file ? `/uploads/${req.file.filename}` : null,
    });

    // Initialize inventory for all branches
    const branches = await Branch.findAll({ where: { is_active: true } });
    await Promise.all(branches.map(b =>
      Inventory.findOrCreate({
        where: { product_id: product.id, branch_id: b.id },
        defaults: { quantity: 0 },
      })
    ));

    await AuditLog.create({
      user_id: req.user.id, action: 'CREATE_PRODUCT', module: 'products',
      description: `Created product: ${name}`, ip_address: req.ip,
      new_values: product.toJSON(),
    });

    res.status(201).json({ success: true, data: product });
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError')
      return res.status(400).json({ error: 'Barcode or SKU already exists' });
    res.status(500).json({ error: err.message });
  }
};

// ── Update product ────────────────────────────────────────
exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByPk(id);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const old = product.toJSON();
    const { cost_price, markup_percentage } = req.body;

    let selling_price = req.body.selling_price;
    if (cost_price && markup_percentage) {
      const cost = parseFloat(cost_price);
      const markup = parseFloat(markup_percentage);
      selling_price = cost + (cost * markup / 100);
    }

    const updates = { ...req.body };
    if (selling_price) updates.selling_price = selling_price;
    if (req.file) updates.image_url = `/uploads/${req.file.filename}`;

    await product.update(updates);

    await AuditLog.create({
      user_id: req.user.id, action: 'UPDATE_PRODUCT', module: 'products',
      description: `Updated product: ${product.name}`, ip_address: req.ip,
      old_values: old, new_values: product.toJSON(),
    });

    res.json({ success: true, data: product });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Delete (deactivate) product ───────────────────────────
exports.delete = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    await product.update({ is_active: false });
    res.json({ success: true, message: 'Product deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Generate barcode image ────────────────────────────────
exports.generateBarcode = async (req, res) => {
  try {
    const { text, type = 'CODE128', includePrice, price, productName } = req.query;
    if (!text) return res.status(400).json({ error: 'Barcode text is required' });

    const png = await bwipjs.toBuffer({
      bcid:        type === 'EAN13' ? 'ean13' : 'code128',
      text,
      scale:       3,
      height:      12,
      includetext: true,
      textxalign:  'center',
    });

    res.set('Content-Type', 'image/png');
    res.send(png);
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate barcode: ' + err.message });
  }
};

// ── Get single product ────────────────────────────────────
exports.getOne = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id, {
      include: [
        { model: Category, as: 'category' },
        { model: Supplier, as: 'supplier' },
      ],
    });
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const inventory = await Inventory.findAll({
      where: { product_id: product.id },
      include: [{ model: Branch, as: 'branch', attributes: ['id','name'] }],
    });

    res.json({ success: true, data: { ...product.toJSON(), inventory } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
