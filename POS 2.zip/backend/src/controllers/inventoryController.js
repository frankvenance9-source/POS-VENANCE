// ============================================================
//  Inventory Controller
// ============================================================
const { sequelize } = require('../config/database');
const { Op } = require('sequelize');
const {
  Inventory, Product, Branch, StockMovement, StockTransfer, StockTransferItem,
  StockCount, StockCountItem, AuditLog, Setting,
} = require('../models');

// ── Stock summary ─────────────────────────────────────────
exports.summary = async (req, res) => {
  try {
    const { branch_id, low_stock } = req.query;
    const invWhere = {};
    if (branch_id) invWhere.branch_id = branch_id;

    const items = await Inventory.findAll({
      where: invWhere,
      include: [
        { model: Product, as: 'product',
          where: { is_active: true },
          include: [{ association: 'category', attributes: ['name'] },
                    { association: 'supplier', attributes: ['name'] }] },
        { model: Branch, as: 'branch', attributes: ['id','name'] },
      ],
      order: [[{ model: Product, as: 'product' }, 'name', 'ASC']],
    });

    // Filter low stock if requested
    const result = low_stock === 'true'
      ? items.filter(i => parseFloat(i.quantity) <= parseFloat(i.product.reorder_level || 0))
      : items;

    res.json({ success: true, data: result, total: result.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Stock adjustment ──────────────────────────────────────
exports.adjust = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { product_id, branch_id, type, quantity, notes } = req.body;

    const inv = await Inventory.findOne({
      where: { product_id, branch_id }, transaction: t, lock: true,
    });
    if (!inv) throw new Error('Inventory record not found');

    const adjQty = parseFloat(quantity);
    const oldQty = parseFloat(inv.quantity);
    let newQty;

    if (type === 'set') {
      newQty = adjQty;
    } else if (type === 'add') {
      newQty = oldQty + adjQty;
    } else if (type === 'subtract') {
      if (oldQty < adjQty) throw new Error('Insufficient stock');
      newQty = oldQty - adjQty;
    } else {
      throw new Error('Invalid adjustment type');
    }

    await inv.update({ quantity: newQty }, { transaction: t });

    const variance = newQty - oldQty;
    await StockMovement.create({
      product_id, branch_id, type: 'adjustment',
      quantity: variance, balance_after: newQty,
      notes, created_by: req.user.id,
      reference_type: 'manual_adjustment',
    }, { transaction: t });

    await AuditLog.create({
      user_id: req.user.id, action: 'STOCK_ADJUSTMENT', module: 'inventory',
      description: `Adjusted product #${product_id}: ${oldQty} → ${newQty}`,
      ip_address: req.ip,
      old_values: { quantity: oldQty },
      new_values: { quantity: newQty },
    }, { transaction: t });

    await t.commit();
    res.json({ success: true, data: { old_quantity: oldQty, new_quantity: newQty } });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Stock movement ledger ─────────────────────────────────
exports.movements = async (req, res) => {
  try {
    const { product_id, branch_id, type, from, to, page = 1, limit = 100 } = req.query;
    const where = {};
    if (product_id) where.product_id = product_id;
    if (branch_id)  where.branch_id  = branch_id;
    if (type)       where.type       = type;
    if (from || to) {
      where.created_at = {};
      if (from) where.created_at[Op.gte] = new Date(from + 'T00:00:00');
      if (to)   where.created_at[Op.lte] = new Date(to   + 'T23:59:59');
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { count, rows } = await StockMovement.findAndCountAll({
      where,
      include: [
        { model: Product, as: 'product', attributes: ['id','name','barcode','unit_of_measure'] },
        { model: Branch,  as: 'branch',  attributes: ['id','name'] },
      ],
      limit: parseInt(limit), offset,
      order: [['created_at','DESC']],
    });

    res.json({ success: true, data: rows, total: count });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── Create transfer ───────────────────────────────────────
exports.createTransfer = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { from_branch_id, to_branch_id, items, notes } = req.body;

    if (from_branch_id === to_branch_id) throw new Error('Source and destination must be different');

    const prefix = (await Setting.findOne({ where: { key: 'transfer_prefix' } }))?.value || 'TRF';
    const transfer_number = `${prefix}-${Date.now()}`;

    const transfer = await StockTransfer.create({
      transfer_number, from_branch_id, to_branch_id,
      status: 'draft', notes, created_by: req.user.id,
    }, { transaction: t });

    for (const item of items) {
      await StockTransferItem.create({
        transfer_id: transfer.id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_cost: item.unit_cost || 0,
      }, { transaction: t });
    }

    await t.commit();
    res.status(201).json({ success: true, data: transfer });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Confirm transfer (dispatch) ───────────────────────────
exports.dispatchTransfer = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const transfer = await StockTransfer.findByPk(req.params.id, {
      include: [{ model: StockTransferItem, as: 'items' }],
      transaction: t,
    });
    if (!transfer) throw new Error('Transfer not found');
    if (transfer.status !== 'draft') throw new Error('Transfer already dispatched');

    for (const item of transfer.items) {
      const srcInv = await Inventory.findOne({
        where: { product_id: item.product_id, branch_id: transfer.from_branch_id },
        transaction: t, lock: true,
      });
      if (!srcInv || srcInv.quantity < item.quantity)
        throw new Error(`Insufficient stock for product #${item.product_id}`);

      const newSrcQty = parseFloat(srcInv.quantity) - parseFloat(item.quantity);
      await srcInv.update({ quantity: newSrcQty }, { transaction: t });

      await StockMovement.create({
        product_id: item.product_id, branch_id: transfer.from_branch_id,
        type: 'transfer_out', quantity: -item.quantity, balance_after: newSrcQty,
        reference_id: transfer.id, reference_type: 'transfer',
        created_by: req.user.id,
      }, { transaction: t });
    }

    await transfer.update({ status: 'in_transit' }, { transaction: t });
    await t.commit();
    res.json({ success: true, message: 'Transfer dispatched' });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Receive transfer ──────────────────────────────────────
exports.receiveTransfer = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const transfer = await StockTransfer.findByPk(req.params.id, {
      include: [{ model: StockTransferItem, as: 'items' }],
      transaction: t,
    });
    if (!transfer || transfer.status !== 'in_transit')
      throw new Error('Transfer not in transit');

    for (const item of transfer.items) {
      const [dstInv] = await Inventory.findOrCreate({
        where: { product_id: item.product_id, branch_id: transfer.to_branch_id },
        defaults: { quantity: 0 }, transaction: t,
      });
      const newDstQty = parseFloat(dstInv.quantity) + parseFloat(item.quantity);
      await dstInv.update({ quantity: newDstQty }, { transaction: t });

      await StockMovement.create({
        product_id: item.product_id, branch_id: transfer.to_branch_id,
        type: 'transfer_in', quantity: item.quantity, balance_after: newDstQty,
        reference_id: transfer.id, reference_type: 'transfer',
        created_by: req.user.id,
      }, { transaction: t });
    }

    await transfer.update({ status: 'received', approved_by: req.user.id }, { transaction: t });
    await t.commit();
    res.json({ success: true, message: 'Transfer received successfully' });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

// ── Physical stock count ──────────────────────────────────
exports.createCount = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { branch_id, notes } = req.body;

    const count = await StockCount.create({
      branch_id, notes, counted_by: req.user.id, status: 'draft',
    }, { transaction: t });

    // Get all products with current stock
    const inventory = await Inventory.findAll({ where: { branch_id }, transaction: t });
    for (const inv of inventory) {
      await StockCountItem.create({
        count_id: count.id, product_id: inv.product_id,
        system_quantity: inv.quantity, counted_quantity: null,
      }, { transaction: t });
    }

    await t.commit();
    res.status(201).json({ success: true, data: count });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};

exports.completeCount = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { items } = req.body;
    const count = await StockCount.findByPk(req.params.id, { transaction: t });
    if (!count || count.status === 'completed') throw new Error('Invalid count');

    for (const item of items) {
      const ci = await StockCountItem.findOne({
        where: { count_id: count.id, product_id: item.product_id },
        transaction: t, lock: true,
      });
      if (!ci) continue;

      await ci.update({ counted_quantity: item.counted_quantity }, { transaction: t });

      // Adjust inventory to counted quantity
      const inv = await Inventory.findOne({
        where: { product_id: item.product_id, branch_id: count.branch_id },
        transaction: t, lock: true,
      });
      if (inv && item.counted_quantity !== null) {
        const variance = parseFloat(item.counted_quantity) - parseFloat(inv.quantity);
        if (variance !== 0) {
          await inv.update({ quantity: item.counted_quantity }, { transaction: t });
          await StockMovement.create({
            product_id: item.product_id, branch_id: count.branch_id,
            type: 'adjustment', quantity: variance,
            balance_after: item.counted_quantity,
            notes: `Physical count #${count.id}`,
            created_by: req.user.id,
            reference_id: count.id, reference_type: 'stock_count',
          }, { transaction: t });
        }
      }
    }

    await count.update({ status: 'completed', completed_at: new Date() }, { transaction: t });
    await t.commit();
    res.json({ success: true, message: 'Stock count completed and inventory updated' });
  } catch (err) {
    await t.rollback();
    res.status(400).json({ error: err.message });
  }
};
