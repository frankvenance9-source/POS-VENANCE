// ============================================================
//  Routes — Master Router
// ============================================================
const router = require('express').Router();
const multer = require('multer');
const path   = require('path');
const { authenticate, authorize, adminOnly, adminOrManager } = require('../middleware/auth');

const authCtrl     = require('../controllers/authController');
const productCtrl  = require('../controllers/productController');
const salesCtrl    = require('../controllers/salesController');
const inventoryCtrl = require('../controllers/inventoryController');
const purchaseCtrl = require('../controllers/purchaseController');
const reportCtrl   = require('../controllers/reportController');
const adminCtrl    = require('../controllers/adminController');

// ── File upload config ────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../../uploads');
    require('fs').mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp/;
    cb(allowed.test(file.mimetype) ? null : new Error('Only images allowed'), allowed.test(file.mimetype));
  },
});

// ── Auth routes (public) ──────────────────────────────────
router.post('/auth/login',          authCtrl.login);
router.get( '/auth/me',             authenticate, authCtrl.me);
router.post('/auth/change-password',authenticate, authCtrl.changePassword);
router.post('/auth/setup-2fa',      authenticate, authCtrl.setup2FA);
router.post('/auth/enable-2fa',     authenticate, authCtrl.enable2FA);
router.post('/auth/disable-2fa',    authenticate, authCtrl.disable2FA);

// ── Products ──────────────────────────────────────────────
router.get( '/products',                    authenticate, authorize('products.read'), productCtrl.list);
router.get( '/products/barcode/:barcode',   authenticate, authorize('products.read'), productCtrl.findByBarcode);
router.get( '/products/barcode-image',      authenticate, productCtrl.generateBarcode);
router.get( '/products/:id',                authenticate, authorize('products.read'), productCtrl.getOne);
router.post('/products',                    authenticate, authorize('products.write'), upload.single('image'), productCtrl.create);
router.put( '/products/:id',                authenticate, authorize('products.write'), upload.single('image'), productCtrl.update);
router.delete('/products/:id',              authenticate, authorize('products.write'), productCtrl.delete);

// ── Categories ────────────────────────────────────────────
const { Category } = require('../models');
const { Op } = require('sequelize');
router.get( '/categories', authenticate, async (req, res) => {
  const cats = await Category.findAll({ order: [['name','ASC']] });
  res.json({ success: true, data: cats });
});
router.post('/categories', authenticate, authorize('products.write'), async (req, res) => {
  const cat = await Category.create(req.body);
  res.status(201).json({ success: true, data: cat });
});
router.put('/categories/:id', authenticate, authorize('products.write'), async (req, res) => {
  const cat = await Category.findByPk(req.params.id);
  if (!cat) return res.status(404).json({ error: 'Not found' });
  await cat.update(req.body);
  res.json({ success: true, data: cat });
});

// ── Sales ─────────────────────────────────────────────────
router.get( '/sales',               authenticate, authorize('sales.read'),  salesCtrl.list);
router.get( '/sales/daily-summary', authenticate, authorize('sales.read'),  salesCtrl.dailySummary);
router.get( '/sales/:id',           authenticate, authorize('sales.read'),  salesCtrl.getOne);
router.post('/sales',               authenticate, authorize('sales.write'), salesCtrl.create);
router.post('/sales/:id/refund',    authenticate, authorize('sales.refund'), salesCtrl.refund);
router.post('/sales/sync-offline',  authenticate, authorize('sales.write'), salesCtrl.syncOffline);

// ── Inventory ─────────────────────────────────────────────
router.get( '/inventory',                          authenticate, authorize('inventory.read'),       inventoryCtrl.summary);
router.post('/inventory/adjust',                   authenticate, authorize('inventory.adjustment'), inventoryCtrl.adjust);
router.get( '/inventory/movements',                authenticate, authorize('inventory.read'),       inventoryCtrl.movements);
router.get( '/inventory/transfers',                authenticate, authorize('inventory.read'),       async (req, res) => {
  const { StockTransfer } = require('../models');
  const { Branch } = require('../models');
  const transfers = await StockTransfer.findAll({
    include: [
      { model: Branch, as: 'fromBranch', attributes: ['id','name'], foreignKey: 'from_branch_id' },
      { model: Branch, as: 'toBranch',   attributes: ['id','name'], foreignKey: 'to_branch_id' },
    ],
    order: [['created_at','DESC']],
  });
  res.json({ success: true, data: transfers });
});
router.post('/inventory/transfers',                authenticate, authorize('inventory.transfer'),   inventoryCtrl.createTransfer);
router.post('/inventory/transfers/:id/dispatch',   authenticate, authorize('inventory.transfer'),   inventoryCtrl.dispatchTransfer);
router.post('/inventory/transfers/:id/receive',    authenticate, authorize('inventory.transfer'),   inventoryCtrl.receiveTransfer);
router.post('/inventory/counts',                   authenticate, authorize('inventory.adjustment'), inventoryCtrl.createCount);
router.post('/inventory/counts/:id/complete',      authenticate, authorize('inventory.adjustment'), inventoryCtrl.completeCount);

// ── Purchases ─────────────────────────────────────────────
router.get( '/suppliers',         authenticate, authorize('suppliers.read'),   purchaseCtrl.listSuppliers);
router.post('/suppliers',         authenticate, authorize('suppliers.write'),  purchaseCtrl.createSupplier);
router.put( '/suppliers/:id',     authenticate, authorize('suppliers.write'),  purchaseCtrl.updateSupplier);
router.get( '/purchase-orders',   authenticate, authorize('purchases.read'),   purchaseCtrl.listPOs);
router.get( '/purchase-orders/:id', authenticate, authorize('purchases.read'), purchaseCtrl.getPO);
router.post('/purchase-orders',   authenticate, authorize('purchases.write'),  purchaseCtrl.createPO);
router.get( '/grns',              authenticate, authorize('purchases.read'),   async (req, res) => {
  const { GRN, Supplier, Branch } = require('../models');
  const grns = await GRN.findAll({
    include: [
      { model: Supplier, as: 'supplier', attributes: ['id','name'] },
      { model: Branch, as: 'branch', attributes: ['id','name'] },
    ], order: [['created_at','DESC']],
  });
  res.json({ success: true, data: grns });
});
router.post('/grns',              authenticate, authorize('purchases.write'),  purchaseCtrl.createGRN);
router.post('/grns/:id/confirm',  authenticate, authorize('purchases.approve'), purchaseCtrl.confirmGRN);

// ── Customers ─────────────────────────────────────────────
router.get( '/customers',                      authenticate, authorize('customers.read'),  adminCtrl.listCustomers);
router.post('/customers',                      authenticate, authorize('customers.write'), adminCtrl.createCustomer);
router.put( '/customers/:id',                  authenticate, authorize('customers.write'), adminCtrl.updateCustomer);
router.get( '/customers/:id/statement',        authenticate, authorize('customers.read'),  adminCtrl.getCustomerStatement);
router.post('/customers/:id/credit-payment',   authenticate, authorize('customers.write'), adminCtrl.recordCreditPayment);

// ── Expenses ──────────────────────────────────────────────
router.get( '/expenses',     authenticate, authorize('expenses.read'),  adminCtrl.listExpenses);
router.post('/expenses',     authenticate, authorize('expenses.write'), adminCtrl.createExpense);
router.delete('/expenses/:id', authenticate, adminOrManager,           adminCtrl.deleteExpense);

// ── Reports ───────────────────────────────────────────────
router.get('/reports/dashboard',           authenticate, authorize('reports.read'), reportCtrl.dashboard);
router.get('/reports/sales',               authenticate, authorize('reports.read'), reportCtrl.sales);
router.get('/reports/profit-loss',         authenticate, authorize('reports.financial'), reportCtrl.profitLoss);
router.get('/reports/top-products',        authenticate, authorize('reports.read'), reportCtrl.topProducts);
router.get('/reports/inventory-valuation', authenticate, authorize('reports.read'), reportCtrl.inventoryValuation);
router.get('/reports/export/excel',        authenticate, authorize('reports.read'), reportCtrl.exportExcel);
router.get('/reports/export/pdf',          authenticate, authorize('reports.read'), reportCtrl.exportPDF);

// ── Admin: Users, Settings, Branches, Audit ───────────────
router.get( '/users',          authenticate, adminOrManager, adminCtrl.listUsers);
router.post('/users',          authenticate, adminOnly,      adminCtrl.createUser);
router.put( '/users/:id',      authenticate, adminOnly,      adminCtrl.updateUser);
router.patch('/users/:id/toggle', authenticate, adminOnly,   adminCtrl.toggleUser);

router.get( '/branches',       authenticate, adminCtrl.listBranches);
router.post('/branches',       authenticate, adminOnly, adminCtrl.createBranch);

router.get( '/settings',       authenticate, adminCtrl.getSettings);
router.put( '/settings',       authenticate, adminOnly, adminCtrl.updateSettings);

router.get( '/audit-logs',     authenticate, adminOnly, adminCtrl.getAuditLogs);

// ── Payment methods config ────────────────────────────────
router.get('/payment-methods', authenticate, async (req, res) => {
  const { PaymentMethodsConfig } = require('../models');
  // fallback if no model
  try {
    const { sequelize: seq } = require('../config/database');
    const [rows] = await seq.query('SELECT * FROM payment_methods_config WHERE is_active = 1');
    res.json({ success: true, data: rows });
  } catch {
    res.json({ success: true, data: [] });
  }
});

module.exports = router;
