// ============================================================
//  Database Backup Utility
// ============================================================
const { execSync } = require('child_process');
const path = require('path');
const fs   = require('fs');

exports.createBackup = async () => {
  const dir = path.join(__dirname, '../../', process.env.BACKUP_DIR || 'backups');
  fs.mkdirSync(dir, { recursive: true });

  const ts   = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(dir, `backup-${ts}.sql`);

  const { DB_HOST, DB_USER, DB_PASSWORD, DB_NAME } = process.env;
  const cmd = `mysqldump -h${DB_HOST} -u${DB_USER} -p${DB_PASSWORD} ${DB_NAME} > "${file}"`;

  execSync(cmd);
  console.log(`[BACKUP] Database backed up to ${file}`);

  // Clean old backups
  const keepDays = parseInt(process.env.BACKUP_KEEP_DAYS) || 30;
  const cutoff   = Date.now() - keepDays * 24 * 3600 * 1000;
  for (const f of fs.readdirSync(dir)) {
    const fp = path.join(dir, f);
    if (fs.statSync(fp).mtimeMs < cutoff) {
      fs.unlinkSync(fp);
      console.log(`[BACKUP] Deleted old backup: ${f}`);
    }
  }

  return file;
};
