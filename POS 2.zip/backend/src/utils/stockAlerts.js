// ============================================================
//  Stock Alerts Utility
// ============================================================
const { Inventory, Product, Setting } = require('../models');

exports.checkLowStock = async () => {
  const items = await Inventory.findAll({
    include: [{ model: Product, as: 'product', where: { is_active: true } }],
  });
  const low = items.filter(i =>
    parseFloat(i.quantity) <= parseFloat(i.product.reorder_level || 0)
  );
  if (low.length > 0) {
    console.log(`[ALERT] ${low.length} products below reorder level`);
    // TODO: send email via nodemailer using low_stock_email setting
  }
  return low;
};
