// ============================================================
//  Models Index — defines all Sequelize models & associations
// ============================================================
const { sequelize, Sequelize } = require('../config/database');
const { DataTypes } = Sequelize;

// ── Branch ────────────────────────────────────────────────
const Branch = sequelize.define('Branch', {
  name:      { type: DataTypes.STRING(100), allowNull: false },
  address:   DataTypes.TEXT,
  phone:     DataTypes.STRING(20),
  type:      { type: DataTypes.ENUM('shop','warehouse','branch'), defaultValue: 'shop' },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'branches' });

// ── User ──────────────────────────────────────────────────
const User = sequelize.define('User', {
  name:                 { type: DataTypes.STRING(100), allowNull: false },
  email:                { type: DataTypes.STRING(100), allowNull: false, unique: true },
  password:             { type: DataTypes.STRING(255), allowNull: false },
  role:                 { type: DataTypes.ENUM('admin','manager','cashier','stock_manager'), defaultValue: 'cashier' },
  branch_id:            DataTypes.INTEGER,
  phone:                DataTypes.STRING(20),
  is_active:            { type: DataTypes.BOOLEAN, defaultValue: true },
  two_factor_secret:    DataTypes.STRING(255),
  two_factor_enabled:   { type: DataTypes.BOOLEAN, defaultValue: false },
  last_login:           DataTypes.DATE,
}, { tableName: 'users' });

// ── Category ──────────────────────────────────────────────
const Category = sequelize.define('Category', {
  name:           { type: DataTypes.STRING(100), allowNull: false },
  description:    DataTypes.TEXT,
  default_markup: { type: DataTypes.DECIMAL(5,2), defaultValue: 30.00 },
  parent_id:      DataTypes.INTEGER,
}, { tableName: 'categories' });

// ── Supplier ──────────────────────────────────────────────
const Supplier = sequelize.define('Supplier', {
  name:           { type: DataTypes.STRING(100), allowNull: false },
  contact_person: DataTypes.STRING(100),
  phone:          DataTypes.STRING(20),
  email:          DataTypes.STRING(100),
  address:        DataTypes.TEXT,
  tax_number:     DataTypes.STRING(50),
  notes:          DataTypes.TEXT,
  is_active:      { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'suppliers' });

// ── Product ───────────────────────────────────────────────
const Product = sequelize.define('Product', {
  name:              { type: DataTypes.STRING(200), allowNull: false },
  category_id:       DataTypes.INTEGER,
  barcode:           { type: DataTypes.STRING(50), unique: true },
  sku:               { type: DataTypes.STRING(50), unique: true },
  cost_price:        { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  selling_price:     { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  markup_percentage: { type: DataTypes.DECIMAL(5,2), defaultValue: 30 },
  unit_of_measure:   { type: DataTypes.STRING(20), defaultValue: 'pcs' },
  supplier_id:       DataTypes.INTEGER,
  reorder_level:     { type: DataTypes.INTEGER, defaultValue: 0 },
  description:       DataTypes.TEXT,
  image_url:         DataTypes.STRING(500),
  barcode_type:      { type: DataTypes.ENUM('CODE128','EAN13'), defaultValue: 'CODE128' },
  is_active:         { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'products' });

// ── Inventory ─────────────────────────────────────────────
const Inventory = sequelize.define('Inventory', {
  product_id: { type: DataTypes.INTEGER, allowNull: false },
  branch_id:  { type: DataTypes.INTEGER, allowNull: false },
  quantity:   { type: DataTypes.DECIMAL(15,3), defaultValue: 0 },
}, { tableName: 'inventory', updatedAt: 'updated_at', createdAt: false });

// ── StockMovement ─────────────────────────────────────────
const StockMovement = sequelize.define('StockMovement', {
  product_id:     { type: DataTypes.INTEGER, allowNull: false },
  branch_id:      { type: DataTypes.INTEGER, allowNull: false },
  type:           { type: DataTypes.ENUM('purchase','sale','adjustment','transfer_in','transfer_out','opening','return','damage'), allowNull: false },
  quantity:       { type: DataTypes.DECIMAL(15,3), allowNull: false },
  balance_after:  DataTypes.DECIMAL(15,3),
  unit_cost:      DataTypes.DECIMAL(15,2),
  reference_id:   DataTypes.INTEGER,
  reference_type: DataTypes.STRING(50),
  notes:          DataTypes.TEXT,
  created_by:     DataTypes.INTEGER,
}, { tableName: 'stock_movements', updatedAt: false });

// ── Customer ──────────────────────────────────────────────
const Customer = sequelize.define('Customer', {
  name:                { type: DataTypes.STRING(100), allowNull: false },
  phone:               DataTypes.STRING(20),
  email:               DataTypes.STRING(100),
  address:             DataTypes.TEXT,
  credit_limit:        { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  outstanding_balance: { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  is_active:           { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'customers' });

// ── Sale ──────────────────────────────────────────────────
const Sale = sequelize.define('Sale', {
  receipt_number: { type: DataTypes.STRING(50), unique: true, allowNull: false },
  branch_id:      { type: DataTypes.INTEGER, allowNull: false },
  customer_id:    DataTypes.INTEGER,
  cashier_id:     { type: DataTypes.INTEGER, allowNull: false },
  subtotal:       { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  discount:       { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  tax_amount:     { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  total:          { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  cost_total:     { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  profit:         { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  payment_method: { type: DataTypes.ENUM('cash','mobile_money','bank_transfer','card','credit','mixed'), defaultValue: 'cash' },
  amount_paid:    { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  change_amount:  { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  credit_amount:  { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  status:         { type: DataTypes.ENUM('completed','pending','cancelled','refunded'), defaultValue: 'completed' },
  notes:          DataTypes.TEXT,
  synced:         { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'sales' });

// ── SaleItem ──────────────────────────────────────────────
const SaleItem = sequelize.define('SaleItem', {
  sale_id:    { type: DataTypes.INTEGER, allowNull: false },
  product_id: { type: DataTypes.INTEGER, allowNull: false },
  quantity:   { type: DataTypes.DECIMAL(15,3), allowNull: false },
  unit_price: { type: DataTypes.DECIMAL(15,2), allowNull: false },
  cost_price: { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  discount:   { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  total:      { type: DataTypes.DECIMAL(15,2), allowNull: false },
  profit:     { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
}, { tableName: 'sale_items', timestamps: false });

// ── PaymentDetail ─────────────────────────────────────────
const PaymentDetail = sequelize.define('PaymentDetail', {
  sale_id:        { type: DataTypes.INTEGER, allowNull: false },
  payment_method: { type: DataTypes.ENUM('cash','mobile_money','bank_transfer','card','credit'), allowNull: false },
  amount:         { type: DataTypes.DECIMAL(15,2), allowNull: false },
  reference:      DataTypes.STRING(100),
}, { tableName: 'payment_details', updatedAt: false });

// ── CreditPayment ─────────────────────────────────────────
const CreditPayment = sequelize.define('CreditPayment', {
  customer_id:    { type: DataTypes.INTEGER, allowNull: false },
  sale_id:        DataTypes.INTEGER,
  amount:         { type: DataTypes.DECIMAL(15,2), allowNull: false },
  payment_method: { type: DataTypes.ENUM('cash','mobile_money','bank_transfer','card'), defaultValue: 'cash' },
  reference:      DataTypes.STRING(100),
  received_by:    DataTypes.INTEGER,
  notes:          DataTypes.TEXT,
}, { tableName: 'credit_payments', updatedAt: false });

// ── PurchaseOrder ─────────────────────────────────────────
const PurchaseOrder = sequelize.define('PurchaseOrder', {
  po_number:     { type: DataTypes.STRING(50), unique: true, allowNull: false },
  supplier_id:   { type: DataTypes.INTEGER, allowNull: false },
  branch_id:     { type: DataTypes.INTEGER, allowNull: false },
  status:        { type: DataTypes.ENUM('draft','sent','partial','received','cancelled'), defaultValue: 'draft' },
  subtotal:      { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  tax_amount:    { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  total:         { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  notes:         DataTypes.TEXT,
  ordered_by:    DataTypes.INTEGER,
  expected_date: DataTypes.DATEONLY,
}, { tableName: 'purchase_orders' });

// ── PurchaseOrderItem ─────────────────────────────────────
const PurchaseOrderItem = sequelize.define('PurchaseOrderItem', {
  po_id:             { type: DataTypes.INTEGER, allowNull: false },
  product_id:        { type: DataTypes.INTEGER, allowNull: false },
  quantity_ordered:  { type: DataTypes.DECIMAL(15,3), allowNull: false },
  quantity_received: { type: DataTypes.DECIMAL(15,3), defaultValue: 0 },
  unit_cost:         { type: DataTypes.DECIMAL(15,2), allowNull: false },
  total:             { type: DataTypes.DECIMAL(15,2), allowNull: false },
}, { tableName: 'purchase_order_items', timestamps: false });

// ── GRN ───────────────────────────────────────────────────
const GRN = sequelize.define('GRN', {
  grn_number:   { type: DataTypes.STRING(50), unique: true, allowNull: false },
  po_id:        DataTypes.INTEGER,
  supplier_id:  { type: DataTypes.INTEGER, allowNull: false },
  branch_id:    { type: DataTypes.INTEGER, allowNull: false },
  status:       { type: DataTypes.ENUM('draft','confirmed'), defaultValue: 'draft' },
  total_cost:   { type: DataTypes.DECIMAL(15,2), defaultValue: 0 },
  notes:        DataTypes.TEXT,
  received_by:  DataTypes.INTEGER,
  received_at:  DataTypes.DATE,
}, { tableName: 'grns', updatedAt: false });

// ── GRNItem ───────────────────────────────────────────────
const GRNItem = sequelize.define('GRNItem', {
  grn_id:            { type: DataTypes.INTEGER, allowNull: false },
  product_id:        { type: DataTypes.INTEGER, allowNull: false },
  quantity_received: { type: DataTypes.DECIMAL(15,3), allowNull: false },
  unit_cost:         { type: DataTypes.DECIMAL(15,2), allowNull: false },
  total:             { type: DataTypes.DECIMAL(15,2), allowNull: false },
}, { tableName: 'grn_items', timestamps: false });

// ── StockTransfer ─────────────────────────────────────────
const StockTransfer = sequelize.define('StockTransfer', {
  transfer_number: { type: DataTypes.STRING(50), unique: true, allowNull: false },
  from_branch_id:  { type: DataTypes.INTEGER, allowNull: false },
  to_branch_id:    { type: DataTypes.INTEGER, allowNull: false },
  status:          { type: DataTypes.ENUM('draft','in_transit','received','cancelled'), defaultValue: 'draft' },
  notes:           DataTypes.TEXT,
  created_by:      DataTypes.INTEGER,
  approved_by:     DataTypes.INTEGER,
}, { tableName: 'stock_transfers' });

// ── StockTransferItem ─────────────────────────────────────
const StockTransferItem = sequelize.define('StockTransferItem', {
  transfer_id: { type: DataTypes.INTEGER, allowNull: false },
  product_id:  { type: DataTypes.INTEGER, allowNull: false },
  quantity:    { type: DataTypes.DECIMAL(15,3), allowNull: false },
  unit_cost:   DataTypes.DECIMAL(15,2),
}, { tableName: 'stock_transfer_items', timestamps: false });

// ── Expense ───────────────────────────────────────────────
const Expense = sequelize.define('Expense', {
  branch_id:      { type: DataTypes.INTEGER, allowNull: false },
  category:       { type: DataTypes.ENUM('transport','rent','utilities','salaries','miscellaneous','other'), allowNull: false },
  description:    DataTypes.TEXT,
  amount:         { type: DataTypes.DECIMAL(15,2), allowNull: false },
  payment_method: { type: DataTypes.ENUM('cash','mobile_money','bank_transfer'), defaultValue: 'cash' },
  reference:      DataTypes.STRING(100),
  expense_date:   { type: DataTypes.DATEONLY, allowNull: false },
  recorded_by:    DataTypes.INTEGER,
}, { tableName: 'expenses', updatedAt: false });

// ── Setting ───────────────────────────────────────────────
const Setting = sequelize.define('Setting', {
  key:         { type: DataTypes.STRING(100), unique: true, allowNull: false },
  value:       DataTypes.TEXT,
  description: DataTypes.STRING(255),
}, { tableName: 'settings', createdAt: false });

// ── AuditLog ──────────────────────────────────────────────
const AuditLog = sequelize.define('AuditLog', {
  user_id:     DataTypes.INTEGER,
  action:      { type: DataTypes.STRING(100), allowNull: false },
  module:      { type: DataTypes.STRING(50), allowNull: false },
  description: DataTypes.TEXT,
  ip_address:  DataTypes.STRING(45),
  old_values:  DataTypes.JSON,
  new_values:  DataTypes.JSON,
}, { tableName: 'audit_logs', updatedAt: false });

// ── StockCount ────────────────────────────────────────────
const StockCount = sequelize.define('StockCount', {
  branch_id:    { type: DataTypes.INTEGER, allowNull: false },
  status:       { type: DataTypes.ENUM('draft','completed'), defaultValue: 'draft' },
  counted_by:   DataTypes.INTEGER,
  notes:        DataTypes.TEXT,
  completed_at: DataTypes.DATE,
}, { tableName: 'stock_counts', updatedAt: false });

const StockCountItem = sequelize.define('StockCountItem', {
  count_id:         { type: DataTypes.INTEGER, allowNull: false },
  product_id:       { type: DataTypes.INTEGER, allowNull: false },
  system_quantity:  DataTypes.DECIMAL(15,3),
  counted_quantity: DataTypes.DECIMAL(15,3),
}, { tableName: 'stock_count_items', timestamps: false });

// ============================================================
//  ASSOCIATIONS
// ============================================================
Branch.hasMany(User,          { foreignKey: 'branch_id', as: 'users' });
User.belongsTo(Branch,        { foreignKey: 'branch_id', as: 'branch' });

Category.hasMany(Product,     { foreignKey: 'category_id', as: 'products' });
Product.belongsTo(Category,   { foreignKey: 'category_id', as: 'category' });

Supplier.hasMany(Product,     { foreignKey: 'supplier_id', as: 'products' });
Product.belongsTo(Supplier,   { foreignKey: 'supplier_id', as: 'supplier' });

Product.hasMany(Inventory,    { foreignKey: 'product_id' });
Inventory.belongsTo(Product,  { foreignKey: 'product_id', as: 'product' });
Branch.hasMany(Inventory,     { foreignKey: 'branch_id' });
Inventory.belongsTo(Branch,   { foreignKey: 'branch_id', as: 'branch' });

Sale.hasMany(SaleItem,        { foreignKey: 'sale_id', as: 'items' });
SaleItem.belongsTo(Sale,      { foreignKey: 'sale_id' });
SaleItem.belongsTo(Product,   { foreignKey: 'product_id', as: 'product' });
Sale.belongsTo(Customer,      { foreignKey: 'customer_id', as: 'customer' });
Sale.belongsTo(User,          { foreignKey: 'cashier_id', as: 'cashier' });
Sale.belongsTo(Branch,        { foreignKey: 'branch_id', as: 'branch' });
Sale.hasMany(PaymentDetail,   { foreignKey: 'sale_id', as: 'payments' });

Customer.hasMany(CreditPayment, { foreignKey: 'customer_id' });
CreditPayment.belongsTo(Customer, { foreignKey: 'customer_id' });

PurchaseOrder.hasMany(PurchaseOrderItem, { foreignKey: 'po_id', as: 'items' });
PurchaseOrderItem.belongsTo(PurchaseOrder, { foreignKey: 'po_id' });
PurchaseOrderItem.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });
PurchaseOrder.belongsTo(Supplier, { foreignKey: 'supplier_id', as: 'supplier' });
PurchaseOrder.belongsTo(Branch,   { foreignKey: 'branch_id', as: 'branch' });

GRN.hasMany(GRNItem,          { foreignKey: 'grn_id', as: 'items' });
GRNItem.belongsTo(GRN,        { foreignKey: 'grn_id' });
GRNItem.belongsTo(Product,    { foreignKey: 'product_id', as: 'product' });
GRN.belongsTo(Supplier,       { foreignKey: 'supplier_id', as: 'supplier' });
GRN.belongsTo(Branch,         { foreignKey: 'branch_id', as: 'branch' });
GRN.belongsTo(PurchaseOrder,  { foreignKey: 'po_id', as: 'purchase_order' });

StockTransfer.hasMany(StockTransferItem, { foreignKey: 'transfer_id', as: 'items' });
StockTransferItem.belongsTo(StockTransfer, { foreignKey: 'transfer_id' });
StockTransferItem.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

Expense.belongsTo(Branch, { foreignKey: 'branch_id', as: 'branch' });
Expense.belongsTo(User,   { foreignKey: 'recorded_by', as: 'recorded_by_user' });

StockCount.hasMany(StockCountItem, { foreignKey: 'count_id', as: 'items' });
StockCountItem.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

module.exports = {
  sequelize,
  Branch, User, Category, Supplier, Product, Inventory, StockMovement,
  Customer, Sale, SaleItem, PaymentDetail, CreditPayment,
  PurchaseOrder, PurchaseOrderItem, GRN, GRNItem,
  StockTransfer, StockTransferItem,
  Expense, Setting, AuditLog, StockCount, StockCountItem,
};
