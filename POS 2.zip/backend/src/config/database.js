const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME || 'pos_system',
  process.env.DB_USER || 'root',
  process.env.DB_PASSWORD || '',
  {
    host:    process.env.DB_HOST || 'localhost',
    port:    parseInt(process.env.DB_PORT) || 3306,
    dialect: 'mysql',
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
    pool:    { max: 10, min: 2, acquire: 30000, idle: 10000 },
    define:  { underscored: true, timestamps: true },
    timezone: '+03:00', // East Africa Time
  }
);

module.exports = { sequelize, Sequelize };
