# POS & Retail Management System

A full-stack cloud-based Point of Sale and Retail Management System designed for mini retail shops in Tanzania, operating in **Tanzanian Shillings (TZS)**.

## Features

### Front Office (POS)
- ✅ Barcode scanning (CODE128 & EAN13)
- ✅ Product search with live autocomplete
- ✅ Cart management (add, remove, adjust quantity)
- ✅ Multiple payment methods (Cash, M-Pesa, Tigo Pesa, Airtel Money, Bank Transfer, Card, Credit)
- ✅ Customer credit sales & outstanding balance tracking
- ✅ 80mm thermal receipt printing
- ✅ **Offline mode** (IndexedDB + sync when reconnected)
- ✅ Split/mixed payments

### Back Office (Admin)
- ✅ Role-based access (Admin / Manager / Cashier / Stock Manager)
- ✅ Product management with markup auto-calculation
- ✅ Barcode generation & label printing
- ✅ Full inventory management (stock ledger, adjustments, transfers)
- ✅ Purchase orders & GRN workflow
- ✅ Multi-branch support with stock transfers
- ✅ Physical stock counting
- ✅ Customer management & credit statements
- ✅ Expense tracking by category
- ✅ **Profit & Loss reports**
- ✅ Sales trend charts
- ✅ Top-selling products analytics
- ✅ Inventory valuation reports
- ✅ Excel & PDF exports
- ✅ Real-time dashboard (Socket.io)
- ✅ Audit trail for all actions
- ✅ Two-factor authentication (TOTP)
- ✅ Automatic daily database backups

## Quick Start

```bash
# 1. Database
mysql -u root -p < database/schema.sql

# 2. Backend
cd backend
cp .env.example .env    # Edit with your DB credentials
npm install
npm run dev

# 3. Frontend
cd ../frontend
echo "REACT_APP_API_URL=http://localhost:3001/api/v1" > .env
npm install
npm start
```

**Default login:** `admin@myshop.co.tz` / `Admin@1234`

## Project Structure

```
pos-system/
├── database/
│   └── schema.sql          ← Full MySQL schema + seed data
├── backend/
│   ├── server.js            ← Express server entry
│   ├── src/
│   │   ├── config/
│   │   │   └── database.js  ← Sequelize connection
│   │   ├── models/
│   │   │   └── index.js     ← All models + associations
│   │   ├── middleware/
│   │   │   ├── auth.js      ← JWT + RBAC
│   │   │   └── audit.js     ← Audit logging
│   │   ├── controllers/
│   │   │   ├── authController.js
│   │   │   ├── productController.js
│   │   │   ├── salesController.js
│   │   │   ├── inventoryController.js
│   │   │   ├── purchaseController.js
│   │   │   ├── reportController.js
│   │   │   └── adminController.js
│   │   ├── routes/
│   │   │   └── index.js     ← All API routes
│   │   └── utils/
│   │       ├── backup.js
│   │       └── stockAlerts.js
│   └── .env.example
├── frontend/
│   └── src/
│       ├── api/index.js     ← Axios API client
│       ├── store/index.js   ← Zustand stores
│       ├── utils/offlineDB.js ← IndexedDB offline support
│       ├── components/
│       │   ├── layout/      ← AdminLayout, POSLayout
│       │   └── pos/         ← ReceiptModal
│       └── pages/
│           ├── LoginPage.jsx
│           ├── DashboardPage.jsx
│           ├── POSPage.jsx
│           ├── ProductsPage.jsx
│           ├── SalesPage.jsx
│           └── ReportsPage.jsx
└── docs/
    └── DEPLOYMENT.md        ← Full hosting guide
```

## Deployment

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for complete instructions including:
- VPS setup (DigitalOcean/Vultr)
- Nginx reverse proxy configuration
- SSL with Let's Encrypt
- PM2 process management
- Database backup configuration
