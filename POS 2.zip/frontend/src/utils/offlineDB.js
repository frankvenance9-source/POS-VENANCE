// ============================================================
//  Offline DB — IndexedDB via idb library
//  Caches products and queues offline sales for sync
// ============================================================
import { openDB } from 'idb';

const DB_NAME    = 'pos_offline';
const DB_VERSION = 1;

let _db = null;

async function getDB() {
  if (_db) return _db;
  _db = await openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Products cache
      if (!db.objectStoreNames.contains('products')) {
        const ps = db.createObjectStore('products', { keyPath: 'id' });
        ps.createIndex('barcode', 'barcode', { unique: false });
      }
      // Pending offline sales
      if (!db.objectStoreNames.contains('pending_sales')) {
        db.createObjectStore('pending_sales', { keyPath: 'offline_id', autoIncrement: true });
      }
      // Settings cache
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    },
  });
  return _db;
}

// ── Products ──────────────────────────────────────────────
export async function cacheProducts(products) {
  const db = await getDB();
  const tx = db.transaction('products', 'readwrite');
  await Promise.all([
    ...products.map(p => tx.store.put(p)),
    tx.done,
  ]);
}

export async function getCachedProduct(id) {
  const db = await getDB();
  return db.get('products', id);
}

export async function getCachedProductByBarcode(barcode) {
  const db  = await getDB();
  const idx = db.transaction('products').store.index('barcode');
  return idx.get(barcode);
}

export async function getAllCachedProducts() {
  const db = await getDB();
  return db.getAll('products');
}

// ── Pending sales ─────────────────────────────────────────
export async function queueSale(saleData) {
  const db = await getDB();
  const id = await db.add('pending_sales', {
    ...saleData,
    queued_at: new Date().toISOString(),
    synced:    false,
  });
  return id;
}

export async function getPendingSales() {
  const db = await getDB();
  return db.getAll('pending_sales');
}

export async function removePendingSale(offlineId) {
  const db = await getDB();
  return db.delete('pending_sales', offlineId);
}

export async function getPendingSalesCount() {
  const db = await getDB();
  return db.count('pending_sales');
}

// ── Settings cache ────────────────────────────────────────
export async function cacheSettings(settings) {
  const db = await getDB();
  const tx = db.transaction('settings', 'readwrite');
  await Promise.all([
    ...Object.entries(settings).map(([key, value]) => tx.store.put({ key, value })),
    tx.done,
  ]);
}

export async function getCachedSettings() {
  const db = await getDB();
  const rows = await db.getAll('settings');
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

// ── Network status ────────────────────────────────────────
export function isOnline() {
  return navigator.onLine;
}

export function onNetworkChange(callback) {
  window.addEventListener('online',  () => callback(true));
  window.addEventListener('offline', () => callback(false));
}
