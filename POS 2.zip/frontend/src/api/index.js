// ============================================================
//  API Client — Axios with JWT interceptors
// ============================================================
import axios from 'axios';
import toast from 'react-hot-toast';

const BASE_URL = process.env.REACT_APP_API_URL || '/api/v1';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// ── Request interceptor — attach token ────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('pos_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response interceptor — handle errors globally ────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const msg = error.response?.data?.error || 'Network error';

    if (error.response?.status === 401) {
      localStorage.removeItem('pos_token');
      localStorage.removeItem('pos_user');
      window.location.href = '/login';
      return Promise.reject(error);
    }
    if (error.response?.status === 403) {
      toast.error('Access denied: insufficient permissions');
    } else if (error.response?.status === 429) {
      toast.error('Too many requests. Please slow down.');
    } else if (!error.response) {
      toast.error('Network error — check your connection');
    }

    return Promise.reject({ ...error, message: msg });
  }
);

// ── API helpers ───────────────────────────────────────────
export const authAPI = {
  login:          (data) => api.post('/auth/login', data),
  me:             ()     => api.get('/auth/me'),
  changePassword: (data) => api.post('/auth/change-password', data),
  setup2FA:       ()     => api.post('/auth/setup-2fa'),
  enable2FA:      (data) => api.post('/auth/enable-2fa', data),
  disable2FA:     (data) => api.post('/auth/disable-2fa', data),
};

export const productsAPI = {
  list:          (params) => api.get('/products', { params }),
  get:           (id)     => api.get(`/products/${id}`),
  findByBarcode: (bc, branchId) => api.get(`/products/barcode/${bc}`, { params: { branch_id: branchId } }),
  create:        (data)   => api.post('/products', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  update:        (id, data) => api.put(`/products/${id}`, data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  delete:        (id)     => api.delete(`/products/${id}`),
  barcodeImage:  (params) => `${BASE_URL}/products/barcode-image?${new URLSearchParams(params)}`,
  categories: {
    list:   () => api.get('/categories'),
    create: (data) => api.post('/categories', data),
    update: (id, data) => api.put(`/categories/${id}`, data),
  },
};

export const salesAPI = {
  list:         (params) => api.get('/sales', { params }),
  get:          (id)     => api.get(`/sales/${id}`),
  create:       (data)   => api.post('/sales', data),
  refund:       (id)     => api.post(`/sales/${id}/refund`),
  dailySummary: (params) => api.get('/sales/daily-summary', { params }),
  syncOffline:  (data)   => api.post('/sales/sync-offline', data),
  paymentMethods: () => api.get('/payment-methods'),
};

export const inventoryAPI = {
  summary:          (params) => api.get('/inventory', { params }),
  adjust:           (data)   => api.post('/inventory/adjust', data),
  movements:        (params) => api.get('/inventory/movements', { params }),
  transfers: {
    list:     (params) => api.get('/inventory/transfers', { params }),
    create:   (data)   => api.post('/inventory/transfers', data),
    dispatch: (id)     => api.post(`/inventory/transfers/${id}/dispatch`),
    receive:  (id)     => api.post(`/inventory/transfers/${id}/receive`),
  },
  counts: {
    create:   (data)   => api.post('/inventory/counts', data),
    complete: (id, data) => api.post(`/inventory/counts/${id}/complete`, data),
  },
};

export const purchasesAPI = {
  suppliers: {
    list:   (params) => api.get('/suppliers', { params }),
    create: (data)   => api.post('/suppliers', data),
    update: (id, d)  => api.put(`/suppliers/${id}`, d),
  },
  pos: {
    list:   (params) => api.get('/purchase-orders', { params }),
    get:    (id)     => api.get(`/purchase-orders/${id}`),
    create: (data)   => api.post('/purchase-orders', data),
  },
  grn: {
    list:    (params) => api.get('/grns', { params }),
    create:  (data)   => api.post('/grns', data),
    confirm: (id)     => api.post(`/grns/${id}/confirm`),
  },
};

export const customersAPI = {
  list:          (params) => api.get('/customers', { params }),
  create:        (data)   => api.post('/customers', data),
  update:        (id, d)  => api.put(`/customers/${id}`, d),
  statement:     (id, p)  => api.get(`/customers/${id}/statement`, { params: p }),
  creditPayment: (id, d)  => api.post(`/customers/${id}/credit-payment`, d),
};

export const expensesAPI = {
  list:   (params) => api.get('/expenses', { params }),
  create: (data)   => api.post('/expenses', data),
  delete: (id)     => api.delete(`/expenses/${id}`),
};

export const reportsAPI = {
  dashboard:           (params) => api.get('/reports/dashboard', { params }),
  sales:               (params) => api.get('/reports/sales', { params }),
  profitLoss:          (params) => api.get('/reports/profit-loss', { params }),
  topProducts:         (params) => api.get('/reports/top-products', { params }),
  inventoryValuation:  (params) => api.get('/reports/inventory-valuation', { params }),
  exportExcel:         (params) => `${BASE_URL}/reports/export/excel?${new URLSearchParams({ ...params, token: localStorage.getItem('pos_token') })}`,
  exportPDF:           (params) => `${BASE_URL}/reports/export/pdf?${new URLSearchParams({ ...params, token: localStorage.getItem('pos_token') })}`,
};

export const adminAPI = {
  users: {
    list:   () => api.get('/users'),
    create: (data) => api.post('/users', data),
    update: (id, d) => api.put(`/users/${id}`, d),
    toggle: (id) => api.patch(`/users/${id}/toggle`),
  },
  branches: {
    list:   () => api.get('/branches'),
    create: (data) => api.post('/branches', data),
  },
  settings: {
    get:    () => api.get('/settings'),
    update: (data) => api.put('/settings', data),
  },
  auditLogs: (params) => api.get('/audit-logs', { params }),
};

export default api;
