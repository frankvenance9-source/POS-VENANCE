// ============================================================
//  AdminLayout — Sidebar + Topbar shell
// ============================================================
import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, ShoppingCart, Package, Warehouse, ShoppingBag,
  Users, TrendingUp, Settings, FileText, LogOut, Menu, X,
  DollarSign, Store, ChevronRight, Bell, Wifi, WifiOff, Receipt
} from 'lucide-react';
import { useAuthStore, useSettingsStore } from '../../store';
import toast from 'react-hot-toast';

const navItems = [
  { to: '/',           label: 'Dashboard',  icon: LayoutDashboard, roles: ['admin','manager','cashier','stock_manager'] },
  { to: '/pos',        label: 'POS',        icon: ShoppingCart,    roles: ['admin','manager','cashier'], badge: 'POS' },
  { to: '/sales',      label: 'Sales',      icon: Receipt,         roles: ['admin','manager','cashier'] },
  { to: '/products',   label: 'Products',   icon: Package,         roles: ['admin','manager','stock_manager'] },
  { to: '/inventory',  label: 'Inventory',  icon: Warehouse,       roles: ['admin','manager','stock_manager'] },
  { to: '/purchases',  label: 'Purchases',  icon: ShoppingBag,     roles: ['admin','manager','stock_manager'] },
  { to: '/customers',  label: 'Customers',  icon: Users,           roles: ['admin','manager','cashier'] },
  { to: '/expenses',   label: 'Expenses',   icon: DollarSign,      roles: ['admin','manager'] },
  { to: '/reports',    label: 'Reports',    icon: TrendingUp,      roles: ['admin','manager'] },
  { to: '/users',      label: 'Users',      icon: Users,           roles: ['admin','manager'] },
  { to: '/settings',   label: 'Settings',   icon: Settings,        roles: ['admin'] },
  { to: '/audit',      label: 'Audit Log',  icon: FileText,        roles: ['admin'] },
];

function SidebarLink({ item, collapsed, onClick }) {
  return (
    <NavLink
      to={item.to}
      end={item.to === '/'}
      onClick={onClick}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 group
         ${isActive
           ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
           : 'text-slate-300 hover:bg-slate-700 hover:text-white'
         } ${collapsed ? 'justify-center' : ''}`
      }
    >
      <item.icon size={20} className="shrink-0" />
      {!collapsed && (
        <span className="text-sm font-medium truncate">{item.label}</span>
      )}
      {!collapsed && item.badge && (
        <span className="ml-auto bg-blue-500 text-white text-xs px-1.5 py-0.5 rounded-md">
          {item.badge}
        </span>
      )}
    </NavLink>
  );
}

export default function AdminLayout() {
  const [sidebarOpen,   setSidebarOpen]   = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const { user, logout }        = useAuthStore();
  const { shopName, formatCurrency } = useSettingsStore();
  const navigate = useNavigate();

  // Network status
  React.useEffect(() => {
    const on  = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online',  on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  const visibleItems = navItems.filter(i => i.roles.includes(user?.role));

  const handleLogout = () => {
    logout();
    navigate('/login');
    toast.success('Logged out successfully');
  };

  const sidebarWidth = sidebarCollapsed ? 'w-16' : 'w-64';

  return (
    <div className="flex h-screen bg-slate-100 font-sans overflow-hidden">

      {/* ── Mobile overlay ────────────────────────────────── */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── Sidebar ───────────────────────────────────────── */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-30 flex flex-col
        bg-slate-800 transition-all duration-300
        ${sidebarWidth}
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo */}
        <div className={`flex items-center gap-3 px-4 h-16 border-b border-slate-700 ${sidebarCollapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shrink-0">
            <Store size={16} className="text-white" />
          </div>
          {!sidebarCollapsed && (
            <div className="truncate">
              <p className="text-white font-bold text-sm leading-tight truncate">{shopName}</p>
              <p className="text-slate-400 text-xs">POS System</p>
            </div>
          )}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="hidden lg:flex ml-auto text-slate-400 hover:text-white"
          >
            <ChevronRight size={16} className={`transition-transform ${sidebarCollapsed ? '' : 'rotate-180'}`} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-2 py-4 space-y-1">
          {visibleItems.map(item => (
            <SidebarLink
              key={item.to}
              item={item}
              collapsed={sidebarCollapsed}
              onClick={() => setSidebarOpen(false)}
            />
          ))}
        </nav>

        {/* User */}
        <div className={`px-2 py-4 border-t border-slate-700 ${sidebarCollapsed ? 'items-center' : ''}`}>
          {!sidebarCollapsed && (
            <div className="flex items-center gap-2 px-3 py-2 mb-2 rounded-xl bg-slate-700">
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
                {user?.name?.[0]?.toUpperCase()}
              </div>
              <div className="truncate">
                <p className="text-white text-sm font-medium truncate">{user?.name}</p>
                <p className="text-slate-400 text-xs capitalize">{user?.role}</p>
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className={`flex items-center gap-3 w-full px-3 py-2 rounded-xl text-slate-300 hover:bg-red-600 hover:text-white transition-colors ${sidebarCollapsed ? 'justify-center' : ''}`}
          >
            <LogOut size={18} />
            {!sidebarCollapsed && <span className="text-sm font-medium">Logout</span>}
          </button>
        </div>
      </aside>

      {/* ── Main content ──────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center gap-4 px-4 lg:px-6 shrink-0">
          <button
            className="lg:hidden text-slate-600 hover:text-slate-900"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu size={22} />
          </button>

          <div className="flex-1" />

          {/* Online/offline indicator */}
          <div className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-full ${isOnline ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
            {isOnline ? <Wifi size={12} /> : <WifiOff size={12} />}
            {isOnline ? 'Online' : 'Offline'}
          </div>

          {/* User chip */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
              {user?.name?.[0]?.toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-semibold text-slate-800">{user?.name}</p>
              <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
