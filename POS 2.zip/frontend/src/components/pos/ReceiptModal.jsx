// ============================================================
//  ReceiptModal — 80mm thermal receipt with print support
// ============================================================
import React, { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Printer, X, Download } from 'lucide-react';
import { useSettingsStore } from '../../store';
import dayjs from 'dayjs';

const fmt  = (n) => parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 });
const fmtD = (d) => dayjs(d).format('DD/MM/YYYY HH:mm:ss');

function Receipt({ sale, settings }) {
  const {
    shopName = 'My Retail Shop',
    shop_address = '',
    shop_phone = '',
    receipt_footer = 'Asante kwa kununua!',
    receipt_logo = '',
    tax_rate = 0,
  } = settings;

  return (
    <div
      className="receipt-content bg-white font-mono"
      style={{ width: '80mm', padding: '4mm', fontSize: '11px', lineHeight: '1.4' }}
    >
      {/* Header */}
      <div className="text-center mb-2">
        {receipt_logo && (
          <img src={receipt_logo} alt="logo" className="h-12 mx-auto mb-1 object-contain" />
        )}
        <div className="font-bold text-sm">{shopName}</div>
        {shop_address && <div>{shop_address}</div>}
        {shop_phone && <div>Tel: {shop_phone}</div>}
      </div>

      <div className="border-t border-dashed border-black my-1" />

      {/* Receipt info */}
      <div>
        <div className="flex justify-between">
          <span>Receipt #:</span>
          <span className="font-bold">{sale.receipt_number}</span>
        </div>
        <div className="flex justify-between">
          <span>Date:</span>
          <span>{fmtD(sale.created_at)}</span>
        </div>
        <div className="flex justify-between">
          <span>Cashier:</span>
          <span>{sale.cashier?.name}</span>
        </div>
        {sale.customer && (
          <div className="flex justify-between">
            <span>Customer:</span>
            <span>{sale.customer.name}</span>
          </div>
        )}
      </div>

      <div className="border-t border-dashed border-black my-1" />

      {/* Items */}
      <div className="mb-1">
        {(sale.items || []).map((item, i) => (
          <div key={i}>
            <div className="font-medium truncate">{item.product?.name}</div>
            <div className="flex justify-between pl-2">
              <span>{fmt(item.quantity)} × {fmt(item.unit_price)}</span>
              <span>TZS {fmt(item.total)}</span>
            </div>
            {item.discount > 0 && (
              <div className="flex justify-between pl-2 text-gray-500">
                <span>  Discount</span>
                <span>- {fmt(item.discount)}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="border-t border-dashed border-black my-1" />

      {/* Totals */}
      <div>
        <div className="flex justify-between">
          <span>Subtotal:</span>
          <span>TZS {fmt(sale.subtotal)}</span>
        </div>
        {parseFloat(sale.discount) > 0 && (
          <div className="flex justify-between">
            <span>Discount:</span>
            <span>- TZS {fmt(sale.discount)}</span>
          </div>
        )}
        {parseFloat(sale.tax_amount) > 0 && (
          <div className="flex justify-between">
            <span>Tax ({tax_rate}%):</span>
            <span>TZS {fmt(sale.tax_amount)}</span>
          </div>
        )}
        <div className="flex justify-between font-bold text-sm mt-1">
          <span>TOTAL:</span>
          <span>TZS {fmt(sale.total)}</span>
        </div>
      </div>

      <div className="border-t border-dashed border-black my-1" />

      {/* Payment */}
      <div>
        {(sale.payments || []).length > 0
          ? sale.payments.map((p, i) => (
              <div key={i} className="flex justify-between">
                <span className="capitalize">{p.payment_method.replace('_',' ')}:</span>
                <span>TZS {fmt(p.amount)}</span>
              </div>
            ))
          : (
            <div className="flex justify-between">
              <span className="capitalize">{sale.payment_method?.replace('_',' ')}:</span>
              <span>TZS {fmt(sale.amount_paid)}</span>
            </div>
          )
        }
        {parseFloat(sale.change_amount) > 0 && (
          <div className="flex justify-between font-bold">
            <span>Change:</span>
            <span>TZS {fmt(sale.change_amount)}</span>
          </div>
        )}
        {parseFloat(sale.credit_amount) > 0 && (
          <div className="flex justify-between text-red-700 font-bold">
            <span>Credit (Owed):</span>
            <span>TZS {fmt(sale.credit_amount)}</span>
          </div>
        )}
      </div>

      <div className="border-t border-dashed border-black my-2" />

      {/* Footer */}
      <div className="text-center">
        <p>{receipt_footer}</p>
        <p className="text-gray-400 text-xs mt-1">Powered by POS System</p>
      </div>
    </div>
  );
}

export default function ReceiptModal({ sale, onClose }) {
  const receiptRef = useRef();
  const settings   = useSettingsStore();

  const handlePrint = useReactToPrint({
    content: () => receiptRef.current,
    pageStyle: `
      @page { size: 80mm auto; margin: 0; }
      @media print { body { margin: 0; } .receipt-content { width: 80mm; } }
    `,
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 bg-gray-50">
          <h3 className="font-bold text-gray-900">Receipt</h3>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors"
            >
              <Printer size={15} /> Print
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-200 rounded-xl text-gray-600"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Receipt preview */}
        <div className="overflow-y-auto max-h-[calc(100vh-180px)] flex justify-center bg-gray-100 p-4">
          <div className="shadow-lg">
            <div ref={receiptRef}>
              <Receipt sale={sale} settings={settings} />
            </div>
          </div>
        </div>

        {/* New sale button */}
        <div className="px-5 py-4 border-t border-gray-100 bg-gray-50">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold transition-colors"
          >
            New Sale
          </button>
        </div>
      </div>
    </div>
  );
}
