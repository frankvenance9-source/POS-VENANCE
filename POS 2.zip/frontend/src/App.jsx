// ============================================================
//  App.jsx — Main routing with auth guards
// ============================================================
import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore, useSettingsStore } from './store';
import { adminAPI } from './api';

// Layout
import AdminLayout from './components/layout/AdminLayout';
import POSLayout   from './components/layout/POSLayout';

// Pages
import LoginPage       from './pages/LoginPage';
import DashboardPage   from './pages/DashboardPage';
import POSPage         from './pages/POSPage';
import SalesPage       from './pages/SalesPage';
import SaleDetailPage  from './pages/SaleDetailPage';
import ProductsPage    from './pages/ProductsPage';
import { InventoryPage, PurchasesPage, CustomersPage, ExpensesPage,
         UsersPage, SettingsPage, AuditPage } from './pages/stubs';
import ReportsPage     from './pages/ReportsPage';

// ── Auth guard ────────────────────────────────────────────
function PrivateRoute({ children, roles }) {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user?.role)) return <Navigate to="/" replace />;
  return children;
}

// ── Settings loader ───────────────────────────────────────
function SettingsLoader() {
  const { isAuthenticated } = useAuthStore();
  const { setSettings }     = useSettingsStore();

  useEffect(() => {
    if (!isAuthenticated) return;
    adminAPI.settings.get()
      .then(r => setSettings(r.data.data))
      .catch(() => {});
  }, [isAuthenticated, setSettings]);

  return null;
}

export default function App() {
  const { isAuthenticated } = useAuthStore();

  return (
    <BrowserRouter>
      <SettingsLoader />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: { fontFamily: 'Inter, system-ui, sans-serif' },
          success: { iconTheme: { primary: '#16a34a', secondary: '#fff' } },
          error:   { iconTheme: { primary: '#dc2626', secondary: '#fff' } },
        }}
      />
      <Routes>
        {/* Public */}
        <Route path="/login" element={
          isAuthenticated ? <Navigate to="/" replace /> : <LoginPage />
        } />

        {/* POS interface */}
        <Route path="/pos" element={
          <PrivateRoute roles={['admin','manager','cashier']}>
            <POSLayout />
          </PrivateRoute>
        }>
          <Route index element={<POSPage />} />
        </Route>

        {/* Admin / Back-office */}
        <Route path="/" element={
          <PrivateRoute>
            <AdminLayout />
          </PrivateRoute>
        }>
          <Route index element={<DashboardPage />} />

          <Route path="sales"             element={<SalesPage />} />
          <Route path="sales/:id"         element={<SaleDetailPage />} />

          <Route path="products"          element={
            <PrivateRoute roles={['admin','manager','stock_manager']}>
              <ProductsPage />
            </PrivateRoute>
          } />

          <Route path="inventory"         element={
            <PrivateRoute roles={['admin','manager','stock_manager']}>
              <InventoryPage />
            </PrivateRoute>
          } />

          <Route path="purchases"         element={
            <PrivateRoute roles={['admin','manager','stock_manager']}>
              <PurchasesPage />
            </PrivateRoute>
          } />

          <Route path="customers"         element={<CustomersPage />} />
          <Route path="expenses"          element={
            <PrivateRoute roles={['admin','manager']}>
              <ExpensesPage />
            </PrivateRoute>
          } />

          <Route path="reports"           element={
            <PrivateRoute roles={['admin','manager']}>
              <ReportsPage />
            </PrivateRoute>
          } />

          <Route path="users"             element={
            <PrivateRoute roles={['admin','manager']}>
              <UsersPage />
            </PrivateRoute>
          } />

          <Route path="settings"          element={
            <PrivateRoute roles={['admin']}>
              <SettingsPage />
            </PrivateRoute>
          } />

          <Route path="audit"             element={
            <PrivateRoute roles={['admin']}>
              <AuditPage />
            </PrivateRoute>
          } />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
