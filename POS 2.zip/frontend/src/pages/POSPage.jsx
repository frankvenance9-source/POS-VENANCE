// ============================================================
//  POSPage — Full Point-of-Sale Interface
// ============================================================
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  Barcode, Search, Trash2, Plus, Minus, ShoppingCart,
  User, CreditCard, Printer, X, ChevronRight, AlertTriangle,
  Wifi, WifiOff, Package, ArrowLeft
} from 'lucide-react';
import { useCartStore, useAuthStore, useSettingsStore } from '../store';
import { productsAPI, salesAPI, customersAPI } from '../api';
import { queueSale, getCachedProductByBarcode, getAllCachedProducts, getPendingSalesCount } from '../utils/offlineDB';
import ReceiptModal from '../components/pos/ReceiptModal';

// ── Helpers ───────────────────────────────────────────────
const fmt = (n) => `TZS ${parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 })}`;

// ── Payment methods ───────────────────────────────────────
const PAYMENT_METHODS = [
  { id: 'cash',          label: 'Cash',          color: 'bg-green-100 text-green-800 border-green-300' },
  { id: 'mobile_money',  label: 'Mobile Money',  color: 'bg-yellow-100 text-yellow-800 border-yellow-300' },
  { id: 'bank_transfer', label: 'Bank Transfer', color: 'bg-blue-100 text-blue-800 border-blue-300' },
  { id: 'card',          label: 'Card',          color: 'bg-purple-100 text-purple-800 border-purple-300' },
  { id: 'credit',        label: 'Credit',        color: 'bg-red-100 text-red-800 border-red-300' },
];

export default function POSPage() {
  const navigate = useNavigate();
  const barcodeRef  = useRef(null);
  const { user }    = useAuthStore();
  const { shopName, branchId } = useSettingsStore();

  const {
    items, customer, discount,
    addItem, updateQty, removeItem, setCustomer, setDiscount, clearCart,
    getSubtotal, getTotal, getItemCount,
  } = useCartStore();

  const [barcodeInput,    setBarcodeInput]    = useState('');
  const [searchQuery,     setSearchQuery]     = useState('');
  const [searchResults,   setSearchResults]   = useState([]);
  const [searchOpen,      setSearchOpen]      = useState(false);
  const [isOnline,        setIsOnline]        = useState(navigator.onLine);
  const [pendingCount,    setPendingCount]    = useState(0);

  // Checkout state
  const [checkoutOpen,    setCheckoutOpen]    = useState(false);
  const [paymentMethod,   setPaymentMethod]   = useState('cash');
  const [amountTendered,  setAmountTendered]  = useState('');
  const [reference,       setReference]       = useState('');
  const [processing,      setProcessing]      = useState(false);

  // Receipt
  const [lastSale,        setLastSale]        = useState(null);
  const [receiptOpen,     setReceiptOpen]     = useState(false);

  // Customer search
  const [custSearch,      setCustSearch]      = useState('');
  const [custResults,     setCustResults]     = useState([]);

  // Network monitoring
  useEffect(() => {
    const on  = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  useEffect(() => {
    getPendingSalesCount().then(setPendingCount);
  }, []);

  // Auto-focus barcode input
  useEffect(() => { barcodeRef.current?.focus(); }, [checkoutOpen]);

  // Barcode scanner handler
  const handleBarcodeScan = useCallback(async (e) => {
    if (e.key !== 'Enter') return;
    const code = barcodeInput.trim();
    if (!code) return;

    setBarcodeInput('');
    try {
      let product;
      if (isOnline) {
        const res = await productsAPI.findByBarcode(code, branchId);
        product = res.data.data;
      } else {
        product = await getCachedProductByBarcode(code);
        if (!product) { toast.error('Product not found in offline cache'); return; }
      }

      if (!product.is_active) { toast.error('This product is inactive'); return; }

      const stockQty = product.current_stock || 0;
      const inCart   = items.find(i => i.product_id === product.id)?.quantity || 0;
      if (stockQty <= inCart) {
        toast.error(`Insufficient stock: ${product.name}`);
        return;
      }

      addItem(product);
      toast.success(`${product.name} added`, { duration: 1500, icon: '🛒' });
    } catch (err) {
      toast.error('Product not found');
    }
    barcodeRef.current?.focus();
  }, [barcodeInput, isOnline, branchId, items, addItem]);

  // Product search
  useEffect(() => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      if (isOnline) {
        const res = await productsAPI.list({ search: searchQuery, limit: 20, active: 'true' });
        setSearchResults(res.data.data || []);
      } else {
        const all = await getAllCachedProducts();
        setSearchResults(all.filter(p =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.barcode?.includes(searchQuery)
        ).slice(0, 20));
      }
    }, 300);
    return () => clearTimeout(t);
  }, [searchQuery, isOnline]);

  // Customer search
  useEffect(() => {
    if (!custSearch.trim()) { setCustResults([]); return; }
    const t = setTimeout(async () => {
      const res = await customersAPI.list({ search: custSearch, limit: 5 });
      setCustResults(res.data.data || []);
    }, 300);
    return () => clearTimeout(t);
  }, [custSearch]);

  // Checkout submit
  const handleCheckout = async () => {
    if (!items.length) { toast.error('Cart is empty'); return; }

    const total      = getTotal();
    const tendered   = parseFloat(amountTendered) || 0;
    const isCredit   = paymentMethod === 'credit';

    if (!isCredit && tendered < total) {
      toast.error('Amount tendered is less than total');
      return;
    }
    if (isCredit && !customer) {
      toast.error('Credit sales require a customer account');
      return;
    }

    setProcessing(true);

    const saleData = {
      branch_id:   branchId || 1,
      customer_id: customer?.id || null,
      items:       items.map(i => ({
        product_id: i.product_id, quantity: i.quantity,
        unit_price: i.unit_price, discount: i.discount || 0,
      })),
      payments: [{
        payment_method: paymentMethod,
        amount: isCredit ? total : tendered,
        reference: reference || null,
      }],
      discount,
      notes: '',
    };

    try {
      if (isOnline) {
        const res = await salesAPI.create(saleData);
        setLastSale(res.data.data);
        setReceiptOpen(true);
        clearCart();
        setCheckoutOpen(false);
        setAmountTendered('');
        toast.success(`Sale complete — ${fmt(total)}`);
      } else {
        // Queue offline
        const offlineId = await queueSale({
          ...saleData,
          receipt_number: `OFFLINE-${Date.now()}`,
          total,
        });
        setPendingCount(c => c + 1);
        clearCart();
        setCheckoutOpen(false);
        toast.success('Sale saved offline — will sync when online', { duration: 4000 });
      }
    } catch (err) {
      toast.error(err.message || 'Checkout failed');
    } finally {
      setProcessing(false);
    }
  };

  const subtotal = getSubtotal();
  const total    = getTotal();
  const change   = Math.max(0, (parseFloat(amountTendered) || 0) - total);

  return (
    <div className="flex h-screen bg-gray-50 font-sans overflow-hidden">

      {/* ── Left: Product selector ────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* Topbar */}
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 rounded-lg hover:bg-gray-100">
            <ArrowLeft size={18} className="text-gray-600" />
          </button>
          <div>
            <h1 className="font-bold text-gray-900">{shopName} — POS</h1>
            <p className="text-xs text-gray-500">{user?.name} • {new Date().toLocaleString('en-TZ')}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {pendingCount > 0 && (
              <span className="bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full font-medium">
                {pendingCount} pending sync
              </span>
            )}
            <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full font-medium ${isOnline ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {isOnline ? <Wifi size={11} /> : <WifiOff size={11} />}
              {isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        </div>

        {/* Barcode & search */}
        <div className="p-4 bg-white border-b border-gray-100 flex gap-2">
          <div className="flex-1 relative">
            <Barcode size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              ref={barcodeRef}
              value={barcodeInput}
              onChange={e => setBarcodeInput(e.target.value)}
              onKeyDown={handleBarcodeScan}
              placeholder="Scan barcode or press Enter..."
              className="w-full pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-gray-50"
              autoComplete="off"
            />
          </div>
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={searchQuery}
              onChange={e => { setSearchQuery(e.target.value); setSearchOpen(true); }}
              onFocus={() => setSearchOpen(true)}
              onBlur={() => setTimeout(() => setSearchOpen(false), 200)}
              placeholder="Search products..."
              className="w-full pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-gray-50"
            />
            {/* Search dropdown */}
            {searchOpen && searchResults.length > 0 && (
              <div className="absolute top-full mt-1 left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-xl z-50 max-h-72 overflow-y-auto">
                {searchResults.map(p => (
                  <button
                    key={p.id}
                    onMouseDown={() => { addItem(p); setSearchQuery(''); setSearchResults([]); barcodeRef.current?.focus(); }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-blue-50 transition-colors text-left border-b border-gray-50 last:border-0"
                  >
                    <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center shrink-0">
                      {p.image_url
                        ? <img src={p.image_url} alt="" className="w-full h-full object-cover rounded-lg" />
                        : <Package size={14} className="text-gray-400" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{p.name}</p>
                      <p className="text-xs text-gray-500">{p.barcode}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-blue-700">{fmt(p.selling_price)}</p>
                      <p className="text-xs text-gray-400">Stock: {p.current_stock || 0}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto p-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-3">
              <ShoppingCart size={56} className="opacity-20" />
              <p className="text-lg font-medium">Cart is empty</p>
              <p className="text-sm">Scan a barcode or search for a product</p>
            </div>
          ) : (
            <div className="space-y-2">
              {items.map((item, idx) => (
                <CartItem key={item.product_id} item={item} onUpdateQty={updateQty} onRemove={removeItem} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Right: Order summary & checkout ──────────────── */}
      <div className="w-80 xl:w-96 bg-white border-l border-gray-200 flex flex-col shrink-0">

        {/* Customer */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Customer</span>
            {customer && (
              <button onClick={() => setCustomer(null)} className="text-xs text-red-500 hover:text-red-700">Remove</button>
            )}
          </div>
          {customer ? (
            <div className="flex items-center gap-2 bg-blue-50 rounded-xl px-3 py-2">
              <User size={14} className="text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-900">{customer.name}</p>
                <p className="text-xs text-blue-600">{customer.phone} • Balance: {fmt(customer.outstanding_balance)}</p>
              </div>
            </div>
          ) : (
            <div className="relative">
              <input
                value={custSearch}
                onChange={e => setCustSearch(e.target.value)}
                onBlur={() => setTimeout(() => setCustResults([]), 200)}
                placeholder="Search customer (optional)..."
                className="w-full pl-3 pr-3 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {custResults.length > 0 && (
                <div className="absolute top-full mt-1 left-0 right-0 bg-white border border-gray-200 rounded-xl shadow-xl z-50">
                  {custResults.map(c => (
                    <button
                      key={c.id}
                      onMouseDown={() => { setCustomer(c); setCustSearch(''); setCustResults([]); }}
                      className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm"
                    >
                      <p className="font-medium">{c.name}</p>
                      <p className="text-xs text-gray-500">{c.phone}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Order summary */}
        <div className="flex-1 p-4 overflow-y-auto">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Order Summary</h3>

          {/* Item count */}
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Items ({getItemCount()})</span>
            <span className="font-medium">{fmt(subtotal)}</span>
          </div>

          {/* Discount */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm text-gray-600 w-24">Discount</span>
            <input
              type="number"
              value={discount || ''}
              onChange={e => setDiscount(e.target.value)}
              placeholder="0"
              className="flex-1 text-sm border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500 text-right"
            />
            <span className="text-xs text-gray-400">TZS</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm mb-1 text-red-600">
              <span>Discount</span><span>- {fmt(discount)}</span>
            </div>
          )}

          <div className="border-t border-gray-200 pt-3 mt-2">
            <div className="flex justify-between font-bold text-lg">
              <span>TOTAL</span>
              <span className="text-blue-700">{fmt(total)}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-gray-200 space-y-2">
          <button
            onClick={clearCart}
            disabled={!items.length}
            className="w-full py-2.5 rounded-xl border border-gray-300 text-gray-700 text-sm font-medium hover:bg-gray-50 disabled:opacity-40 transition-colors flex items-center justify-center gap-2"
          >
            <Trash2 size={15} /> Clear Cart
          </button>
          <button
            onClick={() => setCheckoutOpen(true)}
            disabled={!items.length}
            className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-base transition-colors disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30"
          >
            <CreditCard size={18} /> Checkout — {fmt(total)}
          </button>
        </div>
      </div>

      {/* ── Checkout modal ────────────────────────────────── */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h2 className="font-bold text-xl text-gray-900">Payment</h2>
              <button onClick={() => setCheckoutOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl">
                <X size={18} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {/* Total */}
              <div className="bg-blue-50 rounded-2xl p-4 text-center">
                <p className="text-sm text-blue-600 font-medium mb-1">Total Due</p>
                <p className="text-3xl font-black text-blue-700">{fmt(total)}</p>
              </div>

              {/* Payment method */}
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {PAYMENT_METHODS.map(m => (
                    <button
                      key={m.id}
                      onClick={() => setPaymentMethod(m.id)}
                      className={`py-2.5 px-2 rounded-xl border-2 text-xs font-semibold transition-all ${
                        paymentMethod === m.id
                          ? 'border-blue-600 bg-blue-600 text-white'
                          : 'border-gray-200 text-gray-700 hover:border-blue-300'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount */}
              {paymentMethod !== 'credit' && (
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">
                    {paymentMethod === 'cash' ? 'Amount Tendered' : 'Amount'}
                  </label>
                  <input
                    type="number"
                    value={amountTendered}
                    onChange={e => setAmountTendered(e.target.value)}
                    placeholder={total.toString()}
                    className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-xl font-bold text-right focus:outline-none focus:border-blue-500"
                    autoFocus
                  />
                  {/* Quick amounts */}
                  <div className="flex gap-2 mt-2">
                    {[total, Math.ceil(total / 10000) * 10000, Math.ceil(total / 50000) * 50000].filter((v, i, a) => a.indexOf(v) === i).map(v => (
                      <button key={v} onClick={() => setAmountTendered(v.toString())}
                        className="flex-1 py-1.5 text-xs bg-gray-100 hover:bg-blue-100 text-gray-700 rounded-lg font-medium transition-colors">
                        {fmt(v)}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Reference for non-cash */}
              {['mobile_money','bank_transfer','card'].includes(paymentMethod) && (
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 block">Reference / Transaction ID</label>
                  <input
                    value={reference}
                    onChange={e => setReference(e.target.value)}
                    placeholder="e.g. M-Pesa ref..."
                    className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}

              {/* Credit warning */}
              {paymentMethod === 'credit' && !customer && (
                <div className="flex items-start gap-2 bg-yellow-50 border border-yellow-200 rounded-xl p-3">
                  <AlertTriangle size={15} className="text-yellow-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-yellow-800">Please select a customer for credit sales</p>
                </div>
              )}

              {/* Change */}
              {paymentMethod === 'cash' && change > 0 && (
                <div className="bg-green-50 rounded-xl p-3 flex justify-between items-center">
                  <span className="text-sm font-semibold text-green-800">Change</span>
                  <span className="text-xl font-black text-green-700">{fmt(change)}</span>
                </div>
              )}

              <button
                onClick={handleCheckout}
                disabled={processing}
                className="w-full py-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-lg transition-colors disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-green-600/30"
              >
                {processing ? (
                  <><span className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full" /> Processing...</>
                ) : (
                  <><CreditCard size={20} /> Complete Sale</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt modal */}
      {receiptOpen && lastSale && (
        <ReceiptModal sale={lastSale} onClose={() => setReceiptOpen(false)} />
      )}
    </div>
  );
}

// ── Cart Item Component ───────────────────────────────────
function CartItem({ item, onUpdateQty, onRemove }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3 hover:border-blue-200 transition-colors">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-gray-900 truncate">{item.product_name}</p>
        <p className="text-xs text-gray-400">{item.unit_price.toLocaleString()} TZS / {item.unit}</p>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => onUpdateQty(item.product_id, item.quantity - 1)}
          className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-red-100 flex items-center justify-center text-gray-600 hover:text-red-600 transition-colors"
        >
          <Minus size={13} />
        </button>
        <input
          type="number"
          value={item.quantity}
          onChange={e => onUpdateQty(item.product_id, parseFloat(e.target.value) || 0)}
          className="w-12 text-center text-sm font-bold border border-gray-200 rounded-lg py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={() => onUpdateQty(item.product_id, item.quantity + 1)}
          className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-blue-100 flex items-center justify-center text-gray-600 hover:text-blue-600 transition-colors"
        >
          <Plus size={13} />
        </button>
      </div>

      <div className="text-right shrink-0 w-24">
        <p className="text-sm font-bold text-gray-900">{item.total.toLocaleString()}</p>
        <p className="text-xs text-gray-400">TZS</p>
      </div>

      <button
        onClick={() => onRemove(item.product_id)}
        className="w-7 h-7 rounded-lg hover:bg-red-100 flex items-center justify-center text-gray-300 hover:text-red-500 transition-colors shrink-0"
      >
        <Trash2 size={13} />
      </button>
    </div>
  );
}
