// ============================================================
//  SalesPage
// ============================================================
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { RefreshCw, Eye, RotateCcw, Filter, Download } from 'lucide-react';
import { salesAPI } from '../api';

const fmt = (n) => `TZS ${parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 })}`;

const STATUS_COLOR = {
  completed: 'bg-green-100 text-green-700',
  pending:   'bg-yellow-100 text-yellow-700',
  cancelled: 'bg-gray-100 text-gray-500',
  refunded:  'bg-red-100 text-red-700',
};

export default function SalesPage() {
  const today = new Date().toISOString().slice(0, 10);
  const [sales,   setSales]   = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [from,    setFrom]    = useState(today);
  const [to,      setTo]      = useState(today);
  const [status,  setStatus]  = useState('');
  const [page,    setPage]    = useState(1);
  const [total,   setTotal]   = useState(0);

  const load = async () => {
    setLoading(true);
    try {
      const [sRes, dRes] = await Promise.all([
        salesAPI.list({ from, to, status, page, limit: 30 }),
        salesAPI.dailySummary({ date: from }),
      ]);
      setSales(sRes.data.data || []);
      setTotal(sRes.data.total || 0);
      setSummary(sRes.data.summary);
    } catch { toast.error('Failed to load sales'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [from, to, status, page]);

  const handleRefund = async (id) => {
    if (!window.confirm('Refund this sale and restore inventory?')) return;
    await salesAPI.refund(id);
    toast.success('Sale refunded');
    load();
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black text-gray-900">Sales</h1>
        <Link to="/pos" className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-600/30 hover:bg-blue-700">
          + New Sale
        </Link>
      </div>

      {/* Summary cards */}
      {summary && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Transactions', value: summary.count || 0 },
            { label: 'Revenue', value: fmt(summary.total_sales) },
            { label: 'Profit', value: fmt(summary.total_profit) },
            { label: 'Discounts', value: fmt(summary.discounts) },
          ].map(k => (
            <div key={k.label} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm text-center">
              <p className="text-xl font-black text-gray-900">{k.value}</p>
              <p className="text-sm text-gray-500">{k.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-gray-100 p-4 flex flex-wrap gap-3 items-center">
        <Filter size={15} className="text-gray-400" />
        <input type="date" value={from} onChange={e => setFrom(e.target.value)}
          className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        <span className="text-gray-400 text-sm">to</span>
        <input type="date" value={to} onChange={e => setTo(e.target.value)}
          className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        <select value={status} onChange={e => setStatus(e.target.value)}
          className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
          <option value="">All Status</option>
          <option value="completed">Completed</option>
          <option value="refunded">Refunded</option>
          <option value="cancelled">Cancelled</option>
        </select>
        <button onClick={load} className="ml-auto flex items-center gap-1 text-xs text-blue-600">
          <RefreshCw size={13} /> Refresh
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>{['Receipt #','Date','Cashier','Customer','Total','Profit','Payment','Status','Actions'].map(h =>
                <th key={h} className="text-left px-4 py-3 text-xs font-bold text-gray-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
              )}</tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={9} className="text-center py-10 text-gray-400"><RefreshCw size={20} className="animate-spin mx-auto" /></td></tr>
              ) : sales.map(s => (
                <tr key={s.id} className="hover:bg-blue-50/40 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs font-bold text-blue-700">{s.receipt_number}</td>
                  <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{new Date(s.created_at).toLocaleString('en-TZ')}</td>
                  <td className="px-4 py-3">{s.cashier?.name}</td>
                  <td className="px-4 py-3 text-gray-500">{s.customer?.name || <span className="text-gray-300">Walk-in</span>}</td>
                  <td className="px-4 py-3 font-bold">{fmt(s.total)}</td>
                  <td className="px-4 py-3 text-green-600">{fmt(s.profit)}</td>
                  <td className="px-4 py-3 capitalize text-gray-500 text-xs">{s.payment_method?.replace('_',' ')}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[s.status]}`}>{s.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <Link to={`/sales/${s.id}`} className="p-1.5 hover:bg-blue-100 rounded-lg text-blue-600"><Eye size={13} /></Link>
                      {s.status === 'completed' && (
                        <button onClick={() => handleRefund(s.id)} className="p-1.5 hover:bg-red-100 rounded-lg text-red-500"><RotateCcw size={13} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
