// ============================================================
//  DashboardPage — Live KPIs, charts, alerts
// ============================================================
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp, ShoppingCart, DollarSign, AlertTriangle,
  Package, ArrowUpRight, Users, RefreshCw
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, Legend, PieChart, Pie, Cell
} from 'recharts';
import { reportsAPI } from '../api';
import { useAuthStore, useSettingsStore } from '../store';
import toast from 'react-hot-toast';

const fmt = (n) => `TZS ${parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 })}`;
const COLORS = ['#2563eb','#16a34a','#ea580c','#7c3aed','#db2777'];

function KPICard({ icon: Icon, label, value, sub, color, to }) {
  const Card = (
    <div className={`bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow`}>
      <div className="flex items-start justify-between">
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={20} className="text-white" />
        </div>
        {to && <ArrowUpRight size={16} className="text-gray-400" />}
      </div>
      <p className="text-2xl font-black text-gray-900 mt-3">{value}</p>
      <p className="text-sm font-medium text-gray-700 mt-0.5">{label}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
    </div>
  );
  return to ? <Link to={to} className="block">{Card}</Link> : Card;
}

export default function DashboardPage() {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const { user }              = useAuthStore();
  const { formatCurrency }    = useSettingsStore();

  const load = async () => {
    setLoading(true);
    try {
      const res = await reportsAPI.dashboard();
      setData(res.data.data);
    } catch (err) {
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="flex items-center gap-3 text-gray-500">
        <RefreshCw size={20} className="animate-spin" />
        <span>Loading dashboard...</span>
      </div>
    </div>
  );

  const today = data?.today || {};
  const month = data?.month || {};

  // Chart data
  const trendData = (data?.trend || []).map(t => ({
    month: t.month,
    Revenue: parseFloat(t.revenue || 0),
    Profit:  parseFloat(t.profit  || 0),
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-0.5">Welcome back, {user?.name} — {new Date().toLocaleDateString('en-TZ', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">
            <RefreshCw size={14} /> Refresh
          </button>
          <Link to="/pos" className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/30">
            <ShoppingCart size={16} /> Open POS
          </Link>
        </div>
      </div>

      {/* Today's KPIs */}
      <div>
        <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Today</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            icon={ShoppingCart} label="Sales Today" color="bg-blue-600"
            value={today.transactions || 0}
            sub={`${fmt(today.revenue)}`}
            to="/sales"
          />
          <KPICard
            icon={DollarSign} label="Revenue" color="bg-green-600"
            value={fmt(today.revenue)}
            sub={`Profit: ${fmt(today.profit)}`}
          />
          <KPICard
            icon={TrendingUp} label="Gross Profit" color="bg-purple-600"
            value={fmt(today.profit)}
            sub={today.revenue > 0 ? `Margin: ${((today.profit/today.revenue)*100).toFixed(1)}%` : ''}
          />
          <KPICard
            icon={AlertTriangle} label="Low Stock" color="bg-orange-500"
            value={data?.low_stock?.length || 0}
            sub="Products below reorder level"
            to="/inventory"
          />
        </div>
      </div>

      {/* Month KPIs */}
      <div>
        <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">This Month</h2>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <KPICard icon={ShoppingCart} label="Monthly Sales" color="bg-blue-500"
            value={month.transactions || 0} sub={fmt(month.revenue)} />
          <KPICard icon={DollarSign} label="Monthly Revenue" color="bg-emerald-600"
            value={fmt(month.revenue)} />
          <KPICard icon={TrendingUp} label="Monthly Profit" color="bg-violet-600"
            value={fmt(month.profit)}
            sub={month.revenue > 0 ? `${((month.profit/month.revenue)*100).toFixed(1)}% margin` : ''} />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Revenue trend */}
        <div className="xl:col-span-2 bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-4">Revenue & Profit — Last 6 Months</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tickFormatter={v => `${(v/1000000).toFixed(0)}M`} tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => fmt(v)} />
              <Legend />
              <Line type="monotone" dataKey="Revenue" stroke="#2563eb" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="Profit"  stroke="#16a34a" strokeWidth={2.5} dot={false} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top products */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-4">Top Products — Today</h3>
          {(data?.top_products || []).length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-gray-400">
              <Package size={32} className="opacity-30 mb-2" />
              <p className="text-sm">No sales today yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {(data?.top_products || []).map((p, i) => (
                <div key={p.product_id} className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                    i === 0 ? 'bg-yellow-400' : i === 1 ? 'bg-gray-400' : i === 2 ? 'bg-orange-400' : 'bg-gray-200'
                  }`}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{p.product?.name}</p>
                    <p className="text-xs text-gray-400">{parseFloat(p.qty_sold).toFixed(0)} sold</p>
                  </div>
                  <p className="text-sm font-bold text-blue-700 shrink-0">{fmt(p.revenue)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Low stock alerts */}
      {(data?.low_stock || []).length > 0 && (
        <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle size={18} className="text-orange-500" />
              <h3 className="font-bold text-gray-900">Low Stock Alerts</h3>
            </div>
            <Link to="/inventory?low_stock=true" className="text-xs text-blue-600 hover:underline">View all</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-400 text-xs uppercase tracking-wider">
                  <th className="text-left pb-2">Product</th>
                  <th className="text-right pb-2">Stock</th>
                  <th className="text-right pb-2">Reorder Level</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {(data?.low_stock || []).slice(0, 8).map(item => (
                  <tr key={item.product_id} className="hover:bg-orange-50">
                    <td className="py-2 font-medium text-gray-900">{item.product?.name}</td>
                    <td className={`py-2 text-right font-bold ${parseFloat(item.quantity) === 0 ? 'text-red-600' : 'text-orange-600'}`}>
                      {parseFloat(item.quantity)} {item.product?.unit_of_measure}
                    </td>
                    <td className="py-2 text-right text-gray-400">{item.product?.reorder_level}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
