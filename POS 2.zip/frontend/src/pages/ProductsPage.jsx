// ============================================================
//  ProductsPage — Product management with barcode generator
// ============================================================
import React, { useState, useEffect, useRef } from 'react';
import toast from 'react-hot-toast';
import {
  Plus, Search, Edit2, Trash2, Barcode, Package, RefreshCw,
  ChevronLeft, ChevronRight, Filter, Tag, Download, Image
} from 'lucide-react';
import { productsAPI } from '../api';
import { useSettingsStore } from '../store';

const fmt = (n) => parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 });

const UNITS = ['pcs','kg','g','litre','ml','box','pack','pair','dozen','metre','cm'];

function ProductModal({ product, categories, suppliers, onClose, onSaved }) {
  const [form, setForm] = useState(product || {
    name:'', category_id:'', barcode:'', sku:'', cost_price:'', markup_percentage:'30',
    selling_price:'', unit_of_measure:'pcs', supplier_id:'', reorder_level:'0',
    description:'', barcode_type:'CODE128',
  });
  const [saving,   setSaving]   = useState(false);
  const [imgFile,  setImgFile]  = useState(null);
  const [imgPreview, setImgPreview] = useState(product?.image_url || '');

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm(f => {
      const updated = { ...f, [name]: value };
      // Auto calc selling price
      if ((name === 'cost_price' || name === 'markup_percentage') && updated.cost_price) {
        const cost   = parseFloat(updated.cost_price) || 0;
        const markup = parseFloat(updated.markup_percentage) || 0;
        updated.selling_price = (cost + cost * markup / 100).toFixed(0);
      }
      return updated;
    });
  };

  const handleImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImgFile(file);
    setImgPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name) { toast.error('Product name is required'); return; }
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => v !== '' && fd.append(k, v));
      if (imgFile) fd.append('image', imgFile);

      if (product?.id) {
        await productsAPI.update(product.id, fd);
        toast.success('Product updated');
      } else {
        await productsAPI.create(fd);
        toast.success('Product created');
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.message || 'Failed to save product');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl my-4">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <h2 className="font-bold text-lg text-gray-900">{product ? 'Edit Product' : 'New Product'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl text-gray-500">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Image */}
          <div className="sm:col-span-2 flex items-center gap-4">
            <div className="w-20 h-20 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border-2 border-dashed border-gray-200">
              {imgPreview
                ? <img src={imgPreview} alt="" className="w-full h-full object-cover" />
                : <Package size={28} className="text-gray-300" />
              }
            </div>
            <label className="cursor-pointer flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-sm text-gray-700 hover:bg-gray-50">
              <Image size={15} /> Upload Image
              <input type="file" accept="image/*" className="hidden" onChange={handleImage} />
            </label>
          </div>

          {/* Name */}
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Product Name *</label>
            <input name="name" value={form.name} onChange={onChange} required
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          {/* Category */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Category</label>
            <select name="category_id" value={form.category_id} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">Select category</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {/* Supplier */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Supplier</label>
            <select name="supplier_id" value={form.supplier_id} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">Select supplier</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          {/* Barcode */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Barcode (auto-generated if empty)</label>
            <div className="flex gap-2">
              <input name="barcode" value={form.barcode} onChange={onChange} placeholder="Auto-generate"
                className="flex-1 border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              <select name="barcode_type" value={form.barcode_type} onChange={onChange}
                className="border border-gray-200 rounded-xl px-2 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>CODE128</option><option>EAN13</option>
              </select>
            </div>
          </div>

          {/* SKU */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">SKU (auto-generated)</label>
            <input name="sku" value={form.sku} onChange={onChange} placeholder="Auto-generate"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          {/* Cost price */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Cost Price (TZS) *</label>
            <input name="cost_price" type="number" value={form.cost_price} onChange={onChange} required placeholder="0"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          {/* Markup */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Markup %</label>
            <input name="markup_percentage" type="number" value={form.markup_percentage} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          {/* Selling price */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Selling Price (TZS)</label>
            <input name="selling_price" type="number" value={form.selling_price} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-blue-50 font-bold" />
          </div>

          {/* Unit & reorder */}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Unit</label>
            <select name="unit_of_measure" value={form.unit_of_measure} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              {UNITS.map(u => <option key={u}>{u}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Reorder Level</label>
            <input name="reorder_level" type="number" value={form.reorder_level} onChange={onChange}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          {/* Description */}
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 block">Description</label>
            <textarea name="description" value={form.description} onChange={onChange} rows={2}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
          </div>

          {/* Actions */}
          <div className="sm:col-span-2 flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50">
              Cancel
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold disabled:opacity-60">
              {saving ? 'Saving...' : product ? 'Save Changes' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function ProductsPage() {
  const [products,    setProducts]    = useState([]);
  const [categories,  setCategories]  = useState([]);
  const [suppliers,   setSuppliers]   = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [modalOpen,   setModalOpen]   = useState(false);
  const [editing,     setEditing]     = useState(null);
  const [search,      setSearch]      = useState('');
  const [catFilter,   setCatFilter]   = useState('');
  const [page,        setPage]        = useState(1);
  const [total,       setTotal]       = useState(0);
  const [barcodeProduct, setBarcodeProduct] = useState(null);
  const LIMIT = 25;

  const load = async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT, search, active: 'true' };
      if (catFilter) params.category_id = catFilter;
      const [pRes, cRes, sRes] = await Promise.all([
        productsAPI.list(params),
        productsAPI.categories.list(),
        import('../api').then(m => m.purchasesAPI.suppliers.list()),
      ]);
      setProducts(pRes.data.data || []);
      setTotal(pRes.data.total || 0);
      setCategories(cRes.data.data || []);
      setSuppliers(sRes.data.data || []);
    } catch {
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [page, search, catFilter]);

  const handleDelete = async (id) => {
    if (!window.confirm('Deactivate this product?')) return;
    await productsAPI.delete(id);
    toast.success('Product deactivated');
    load();
  };

  const totalPages = Math.ceil(total / LIMIT);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Products</h1>
          <p className="text-sm text-gray-500">{total} products total</p>
        </div>
        <button onClick={() => { setEditing(null); setModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-600/30 transition-colors">
          <Plus size={16} /> Add Product
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by name, barcode, SKU..."
            className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" />
        </div>
        <select value={catFilter} onChange={e => { setCatFilter(e.target.value); setPage(1); }}
          className="border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {['Product','Category','Barcode','Cost','Selling Price','Markup','Reorder','Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={8} className="text-center py-12 text-gray-400">
                  <RefreshCw size={20} className="animate-spin mx-auto mb-2" />Loading...
                </td></tr>
              ) : products.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-gray-400">
                  <Package size={40} className="mx-auto mb-2 opacity-30" />No products found
                </td></tr>
              ) : products.map(p => (
                <tr key={p.id} className="hover:bg-blue-50/50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-gray-100 overflow-hidden shrink-0 flex items-center justify-center">
                        {p.image_url
                          ? <img src={p.image_url} alt="" className="w-full h-full object-cover" />
                          : <Package size={15} className="text-gray-300" />
                        }
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{p.name}</p>
                        <p className="text-xs text-gray-400">{p.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="bg-gray-100 text-gray-700 text-xs px-2 py-0.5 rounded-full">{p.category?.name || '—'}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <code className="text-xs bg-gray-100 px-2 py-0.5 rounded font-mono">{p.barcode}</code>
                      <button onClick={() => setBarcodeProduct(p)} className="text-blue-500 hover:text-blue-700" title="View barcode">
                        <Barcode size={13} />
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{fmt(p.cost_price)}</td>
                  <td className="px-4 py-3 font-bold text-blue-700">{fmt(p.selling_price)}</td>
                  <td className="px-4 py-3">
                    <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-medium">{p.markup_percentage}%</span>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{p.reorder_level} {p.unit_of_measure}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setEditing(p); setModalOpen(true); }}
                        className="p-1.5 hover:bg-blue-100 rounded-lg text-blue-600 transition-colors">
                        <Edit2 size={13} />
                      </button>
                      <button onClick={() => handleDelete(p.id)}
                        className="p-1.5 hover:bg-red-100 rounded-lg text-red-500 transition-colors">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <p className="text-sm text-gray-500">Page {page} of {totalPages} · {total} products</p>
            <div className="flex items-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-xl hover:bg-gray-100 disabled:opacity-40"><ChevronLeft size={16} /></button>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-2 rounded-xl hover:bg-gray-100 disabled:opacity-40"><ChevronRight size={16} /></button>
            </div>
          </div>
        )}
      </div>

      {/* Barcode viewer modal */}
      {barcodeProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl p-6 text-center shadow-2xl">
            <h3 className="font-bold text-gray-900 mb-3">{barcodeProduct.name}</h3>
            <img
              src={productsAPI.barcodeImage({ text: barcodeProduct.barcode, type: barcodeProduct.barcode_type })}
              alt="barcode"
              className="mx-auto max-h-24"
            />
            <p className="font-mono text-sm mt-2 text-gray-600">{barcodeProduct.barcode}</p>
            <p className="text-sm font-bold text-blue-700 mt-1">TZS {fmt(barcodeProduct.selling_price)}</p>
            <button onClick={() => setBarcodeProduct(null)} className="mt-4 px-6 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-medium">
              Close
            </button>
          </div>
        </div>
      )}

      {/* Product modal */}
      {modalOpen && (
        <ProductModal
          product={editing}
          categories={categories}
          suppliers={suppliers}
          onClose={() => setModalOpen(false)}
          onSaved={load}
        />
      )}
    </div>
  );
}
