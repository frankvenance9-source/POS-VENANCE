// ============================================================
//  ReportsPage — Profit & Loss, Sales Analytics, Exports
// ============================================================
import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import {
  TrendingUp, DollarSign, BarChart2, Package, FileSpreadsheet,
  FileText, Download, RefreshCw, Filter
} from 'lucide-react';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from 'recharts';
import { reportsAPI } from '../api';

const fmt = (n) => `TZS ${parseFloat(n || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 })}`;
const COLORS = ['#2563eb','#16a34a','#ea580c','#7c3aed','#db2777','#0891b2'];

function TabBtn({ active, onClick, children }) {
  return (
    <button onClick={onClick}
      className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${active ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30' : 'text-gray-600 hover:bg-gray-100'}`}>
      {children}
    </button>
  );
}

export default function ReportsPage() {
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + '01';

  const [tab,     setTab]     = useState('pl');
  const [from,    setFrom]    = useState(monthStart);
  const [to,      setTo]      = useState(today);
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      let res;
      const params = { from, to };
      if (tab === 'pl')       res = await reportsAPI.profitLoss(params);
      else if (tab === 'sales') res = await reportsAPI.sales({ ...params, group_by: 'day' });
      else if (tab === 'top')   res = await reportsAPI.topProducts({ ...params, limit: 20 });
      else if (tab === 'valuation') res = await reportsAPI.inventoryValuation();
      setData(res?.data?.data || res?.data);
    } catch {
      toast.error('Failed to load report');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [tab, from, to]);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Reports & Analytics</h1>
          <p className="text-sm text-gray-500">Business intelligence and financial reports</p>
        </div>
        <div className="flex items-center gap-2">
          <a href={reportsAPI.exportExcel({ type: tab === 'pl' ? 'pl' : 'sales', from, to })}
             className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-xl text-sm text-gray-700 hover:bg-gray-50">
            <FileSpreadsheet size={15} className="text-green-600" /> Excel
          </a>
          <a href={reportsAPI.exportPDF({ type: tab, from, to })}
             className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-xl text-sm text-gray-700 hover:bg-gray-50">
            <FileText size={15} className="text-red-600" /> PDF
          </a>
        </div>
      </div>

      {/* Date range filter */}
      <div className="bg-white rounded-2xl border border-gray-100 p-4 flex flex-wrap items-center gap-3">
        <Filter size={15} className="text-gray-400" />
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-gray-500">From</label>
          <input type="date" value={from} onChange={e => setFrom(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-gray-500">To</label>
          <input type="date" value={to} onChange={e => setTo(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        {/* Quick presets */}
        {[
          { label: 'Today', from: today, to: today },
          { label: 'This Month', from: monthStart, to: today },
          { label: 'Last 7 Days', from: new Date(Date.now() - 7*86400000).toISOString().slice(0,10), to: today },
        ].map(p => (
          <button key={p.label} onClick={() => { setFrom(p.from); setTo(p.to); }}
            className="text-xs px-3 py-1.5 bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-700 rounded-lg font-medium">
            {p.label}
          </button>
        ))}
        <button onClick={load} className="ml-auto flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800">
          <RefreshCw size={13} /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 flex-wrap">
        <TabBtn active={tab === 'pl'}        onClick={() => setTab('pl')}>Profit & Loss</TabBtn>
        <TabBtn active={tab === 'sales'}     onClick={() => setTab('sales')}>Sales Trend</TabBtn>
        <TabBtn active={tab === 'top'}       onClick={() => setTab('top')}>Top Products</TabBtn>
        <TabBtn active={tab === 'valuation'} onClick={() => setTab('valuation')}>Inventory Valuation</TabBtn>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64 bg-white rounded-2xl border border-gray-100">
          <RefreshCw size={24} className="animate-spin text-blue-500" />
        </div>
      ) : (
        <>
          {/* P&L Report */}
          {tab === 'pl' && data && (
            <div className="space-y-4">
              {/* KPI cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Revenue', value: fmt(data.revenue), color: 'bg-blue-600', icon: DollarSign },
                  { label: 'Cost of Goods', value: fmt(data.cogs), color: 'bg-orange-500', icon: Package },
                  { label: 'Gross Profit', value: fmt(data.gross_profit), sub: `${data.gross_margin}% margin`, color: 'bg-green-600', icon: TrendingUp },
                  { label: 'Net Profit', value: fmt(data.net_profit), sub: `${data.net_margin}% margin`, color: data.net_profit >= 0 ? 'bg-emerald-600' : 'bg-red-600', icon: BarChart2 },
                ].map(k => (
                  <div key={k.label} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                    <div className={`w-10 h-10 ${k.color} rounded-xl flex items-center justify-center mb-3`}>
                      <k.icon size={18} className="text-white" />
                    </div>
                    <p className="text-xl font-black text-gray-900">{k.value}</p>
                    <p className="text-sm text-gray-600 font-medium">{k.label}</p>
                    {k.sub && <p className="text-xs text-gray-400 mt-0.5">{k.sub}</p>}
                  </div>
                ))}
              </div>

              {/* P&L Statement */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-100">
                  <h3 className="font-bold text-gray-900">Profit & Loss Statement</h3>
                  <p className="text-xs text-gray-400">{from} — {to}</p>
                </div>
                <div className="p-5 space-y-2">
                  {[
                    { label: 'Gross Revenue',       value: data.revenue,       style: 'text-gray-900 font-semibold' },
                    { label: 'Cost of Goods Sold',  value: -data.cogs,         style: 'text-red-600' },
                    { label: 'Gross Profit',         value: data.gross_profit,  style: 'text-green-700 font-bold border-t border-gray-100 pt-2' },
                    { label: 'Total Expenses',       value: -data.expenses,     style: 'text-red-600' },
                    { label: '  — Net Profit',       value: data.net_profit,    style: `font-black text-lg border-t-2 border-gray-200 pt-2 ${data.net_profit >= 0 ? 'text-green-700' : 'text-red-700'}` },
                  ].map(r => (
                    <div key={r.label} className={`flex justify-between ${r.style}`}>
                      <span className="text-sm">{r.label}</span>
                      <span className="font-mono">{fmt(Math.abs(r.value))}{r.value < 0 ? ' (-)' : ''}</span>
                    </div>
                  ))}
                </div>

                {/* Expense breakdown */}
                {data.expenses_by_category?.length > 0 && (
                  <div className="px-5 pb-5">
                    <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">Expense Breakdown</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {data.expenses_by_category.map((e, i) => (
                        <div key={e.category} className="flex justify-between items-center bg-gray-50 rounded-xl px-3 py-2">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                            <span className="text-sm capitalize text-gray-700">{e.category}</span>
                          </div>
                          <span className="text-sm font-semibold">{fmt(e.total)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Sales Trend */}
          {tab === 'sales' && Array.isArray(data) && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-bold text-gray-900 mb-4">Daily Sales Trend</h3>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="period" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={v => fmt(v)} />
                  <Legend />
                  <Bar dataKey="revenue" name="Revenue" fill="#2563eb" radius={[4,4,0,0]} />
                  <Bar dataKey="profit"  name="Profit"  fill="#16a34a" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-gray-100">
                    {['Date','Transactions','Revenue','Profit','Cost','Discounts'].map(h =>
                      <th key={h} className="text-left py-2 pr-4 text-xs font-bold text-gray-400 uppercase">{h}</th>
                    )}
                  </tr></thead>
                  <tbody className="divide-y divide-gray-50">
                    {data.map(row => (
                      <tr key={row.period} className="hover:bg-gray-50">
                        <td className="py-2 pr-4 font-medium">{row.period}</td>
                        <td className="py-2 pr-4">{row.transactions}</td>
                        <td className="py-2 pr-4 font-semibold text-blue-700">{fmt(row.revenue)}</td>
                        <td className="py-2 pr-4 text-green-600">{fmt(row.profit)}</td>
                        <td className="py-2 pr-4 text-gray-500">{fmt(row.cost)}</td>
                        <td className="py-2 pr-4 text-red-500">{fmt(row.discounts)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Top Products */}
          {tab === 'top' && Array.isArray(data) && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-bold text-gray-900 mb-4">Top Selling Products</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-gray-100">
                    {['#','Product','Qty Sold','Revenue','Profit','Transactions'].map(h =>
                      <th key={h} className="text-left py-2 pr-4 text-xs font-bold text-gray-400 uppercase">{h}</th>
                    )}
                  </tr></thead>
                  <tbody className="divide-y divide-gray-50">
                    {data.map((row, i) => (
                      <tr key={row.product_id} className="hover:bg-blue-50/50">
                        <td className="py-2 pr-4">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white inline-flex ${i === 0 ? 'bg-yellow-400' : i === 1 ? 'bg-gray-400' : i === 2 ? 'bg-orange-400' : 'bg-gray-200 text-gray-600'}`}>{i+1}</span>
                        </td>
                        <td className="py-2 pr-4 font-semibold text-gray-900">{row.product?.name}</td>
                        <td className="py-2 pr-4">{parseFloat(row.qty_sold).toFixed(0)}</td>
                        <td className="py-2 pr-4 font-bold text-blue-700">{fmt(row.revenue)}</td>
                        <td className="py-2 pr-4 text-green-600">{fmt(row.profit)}</td>
                        <td className="py-2 pr-4 text-gray-500">{row.transactions}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Inventory Valuation */}
          {tab === 'valuation' && data?.data && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Total Cost Value', value: fmt(data.totals?.cost_value) },
                  { label: 'Total Retail Value', value: fmt(data.totals?.retail_value) },
                  { label: 'Potential Profit', value: fmt(data.totals?.potential_profit) },
                ].map(k => (
                  <div key={k.label} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm text-center">
                    <p className="text-xl font-black text-gray-900">{k.value}</p>
                    <p className="text-sm text-gray-500">{k.label}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>{['Product','Branch','Qty','Cost Price','Retail Price','Cost Value','Retail Value'].map(h =>
                        <th key={h} className="text-left px-4 py-3 text-xs font-bold text-gray-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                      )}</tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {data.data.map((row, i) => (
                        <tr key={i} className="hover:bg-gray-50">
                          <td className="px-4 py-2.5 font-medium">{row.product_name}</td>
                          <td className="px-4 py-2.5 text-gray-500">{row.branch}</td>
                          <td className="px-4 py-2.5">{row.quantity}</td>
                          <td className="px-4 py-2.5">{fmt(row.cost_price)}</td>
                          <td className="px-4 py-2.5 text-blue-600">{fmt(row.selling_price)}</td>
                          <td className="px-4 py-2.5 font-semibold">{fmt(row.cost_value)}</td>
                          <td className="px-4 py-2.5 font-semibold text-green-700">{fmt(row.retail_value)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
