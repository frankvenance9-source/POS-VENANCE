// ── Inventory, Purchases, Customers, Expenses, Users, Settings, Audit ──
// All follow the same pattern as ProductsPage / ReportsPage
// Below are minimal stubs so App.jsx compiles — full implementations
// follow the exact same patterns shown above.

const Stub = (title, desc) => () => (
  <div className="space-y-4">
    <h1 className="text-2xl font-black text-gray-900">{title}</h1>
    <p className="text-gray-500">{desc}</p>
    <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center text-gray-400">
      <p className="text-lg font-medium">Implementation in progress</p>
      <p className="text-sm mt-1">This page follows the same patterns as Products &amp; Reports</p>
    </div>
  </div>
);

export const InventoryPage  = Stub('Inventory',  'Stock management, adjustments, transfers and counts');
export const PurchasesPage  = Stub('Purchases',  'Suppliers, purchase orders and goods receipt notes');
export const CustomersPage  = Stub('Customers',  'Customer accounts, credit sales and statements');
export const ExpensesPage   = Stub('Expenses',   'Business expenses and cost tracking');
export const UsersPage      = Stub('Users',      'System users and role management');
export const SettingsPage   = Stub('Settings',   'Shop settings, receipt customization and system config');
export const AuditPage      = Stub('Audit Log',  'System audit trail and activity monitoring');
