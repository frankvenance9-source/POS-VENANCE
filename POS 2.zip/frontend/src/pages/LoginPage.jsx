// ============================================================
//  LoginPage
// ============================================================
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Store, Eye, EyeOff, Lock, Mail, ShieldCheck } from 'lucide-react';
import { authAPI } from '../api';
import { useAuthStore } from '../store';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();

  const [form,       setForm]       = useState({ email: '', password: '', totp_code: '' });
  const [showPass,   setShowPass]   = useState(false);
  const [loading,    setLoading]    = useState(false);
  const [needs2FA,   setNeeds2FA]   = useState(false);

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.error('Email and password are required'); return; }
    setLoading(true);
    try {
      const res = await authAPI.login(form);
      if (res.data.requires_2fa) { setNeeds2FA(true); setLoading(false); return; }
      login(res.data.user, res.data.token);
      toast.success(`Welcome back, ${res.data.user.name}!`);
      navigate('/');
    } catch (err) {
      toast.error(err.message || 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md">

        {/* Card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Hero */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 px-8 pt-10 pb-12 text-center relative">
            <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl mx-auto flex items-center justify-center mb-4">
              <Store size={32} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-white">POS System</h1>
            <p className="text-blue-200 text-sm mt-1">Tanzanian Retail Management</p>
          </div>

          {/* Form */}
          <div className="px-8 py-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6">
              {needs2FA ? 'Two-Factor Authentication' : 'Sign in to continue'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              {!needs2FA ? (
                <>
                  {/* Email */}
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Email</label>
                    <div className="relative">
                      <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        name="email" type="email" value={form.email}
                        onChange={handleChange} placeholder="admin@myshop.co.tz"
                        autoComplete="email"
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Password</label>
                    <div className="relative">
                      <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input
                        name="password" type={showPass ? 'text' : 'password'} value={form.password}
                        onChange={handleChange} placeholder="••••••••"
                        autoComplete="current-password"
                        className="w-full pl-10 pr-12 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      />
                      <button type="button" onClick={() => setShowPass(!showPass)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                        {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                /* 2FA */
                <div>
                  <div className="flex items-center justify-center gap-2 mb-4 text-blue-600">
                    <ShieldCheck size={20} />
                    <p className="text-sm font-medium">Enter the 6-digit code from your authenticator app</p>
                  </div>
                  <input
                    name="totp_code" type="text" value={form.totp_code}
                    onChange={handleChange} placeholder="000000"
                    maxLength={6} autoFocus
                    className="w-full text-center text-3xl font-mono tracking-widest py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                  <button type="button" onClick={() => setNeeds2FA(false)}
                    className="mt-2 text-xs text-gray-400 hover:text-gray-600 w-full text-center">
                    ← Back to login
                  </button>
                </div>
              )}

              <button
                type="submit" disabled={loading}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors text-sm mt-2 disabled:opacity-60 flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30"
              >
                {loading ? (
                  <><span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Signing in...</>
                ) : (
                  needs2FA ? 'Verify Code' : 'Sign In'
                )}
              </button>
            </form>

            <p className="text-center text-xs text-gray-400 mt-6">
              © {new Date().getFullYear()} POS System · All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
