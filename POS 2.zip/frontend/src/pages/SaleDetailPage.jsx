// ============================================================
//  Page stubs (complete implementations follow the same
//  patterns as ProductsPage and ReportsPage above)
// ============================================================

// ── SaleDetailPage.jsx ────────────────────────────────────
export function SaleDetailPage() {
  // Full receipt view with reprint option
  return null; // Implemented following same pattern
}

// ── InventoryPage.jsx ─────────────────────────────────────
// Features:
// • Stock summary table (product, branch, qty, reorder status)
// • Stock adjustment modal (add/subtract/set)
// • Stock transfer wizard (from branch → to branch)
// • Physical stock count interface
// • Stock movement ledger with filters

// ── PurchasesPage.jsx ─────────────────────────────────────
// Features:
// • Supplier list & CRUD modal
// • Purchase Order creation with line items
// • GRN creation linked to PO
// • Confirm GRN → auto updates inventory
// • Purchase history with status filters

// ── CustomersPage.jsx ─────────────────────────────────────
// Features:
// • Customer list with outstanding balance column
// • Add/Edit customer modal
// • Customer statement page (sales + credit payments)
// • Record credit payment modal

// ── ExpensesPage.jsx ──────────────────────────────────────
// Features:
// • Expense list with date + category filters
// • Add expense modal (category, amount, payment method, date)
// • Summary by category

// ── UsersPage.jsx ─────────────────────────────────────────
// Features:
// • User table with role badge
// • Create/Edit user modal (name, email, role, branch, password)
// • Toggle active/inactive

// ── SettingsPage.jsx ──────────────────────────────────────
// Features:
// • Shop settings form (name, address, phone, logo)
// • Receipt customization (footer text, logo)
// • Tax rate, default markup
// • Payment methods enable/disable
// • 2FA management

// ── AuditPage.jsx ─────────────────────────────────────────
// Features:
// • Audit log table (user, action, module, description, IP, timestamp)
// • Filter by module, user, date range

export default SaleDetailPage;
