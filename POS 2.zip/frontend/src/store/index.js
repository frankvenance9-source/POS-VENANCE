// ============================================================
//  Global Store — Zustand
// ============================================================
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// ── Auth Store ────────────────────────────────────────────
export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:  null,
      token: null,
      isAuthenticated: false,

      login: (user, token) => {
        localStorage.setItem('pos_token', token);
        localStorage.setItem('pos_user', JSON.stringify(user));
        set({ user, token, isAuthenticated: true });
      },

      logout: () => {
        localStorage.removeItem('pos_token');
        localStorage.removeItem('pos_user');
        set({ user: null, token: null, isAuthenticated: false });
      },

      updateUser: (data) => set((s) => ({ user: { ...s.user, ...data } })),

      hasPermission: (role) => {
        const { user } = get();
        if (!user) return false;
        if (user.role === 'admin') return true;
        const roleHierarchy = { manager: 3, stock_manager: 2, cashier: 1 };
        return (roleHierarchy[user.role] || 0) >= (roleHierarchy[role] || 99);
      },

      canAccess: (permission) => {
        const { user } = get();
        if (!user) return false;
        if (user.role === 'admin') return true;
        const perms = {
          manager: ['sales','inventory','purchases','customers','expenses','reports'],
          cashier: ['sales','customers'],
          stock_manager: ['products','inventory','purchases'],
        };
        return (perms[user.role] || []).some(p => permission.startsWith(p));
      },
    }),
    { name: 'pos_auth' }
  )
);

// ── Cart Store — POS ──────────────────────────────────────
export const useCartStore = create((set, get) => ({
  items:       [],
  customer:    null,
  discount:    0,
  note:        '',
  branchId:    null,

  addItem: (product, qty = 1) => {
    set((s) => {
      const existing = s.items.find(i => i.product_id === product.id);
      if (existing) {
        return {
          items: s.items.map(i =>
            i.product_id === product.id
              ? { ...i, quantity: i.quantity + qty, total: (i.quantity + qty) * i.unit_price }
              : i
          ),
        };
      }
      return {
        items: [...s.items, {
          product_id:   product.id,
          product_name: product.name,
          barcode:      product.barcode,
          unit:         product.unit_of_measure,
          unit_price:   parseFloat(product.selling_price),
          cost_price:   parseFloat(product.cost_price),
          quantity:     qty,
          discount:     0,
          total:        parseFloat(product.selling_price) * qty,
          current_stock: product.current_stock || 0,
        }],
      };
    });
  },

  updateQty: (product_id, quantity) => {
    if (quantity <= 0) { get().removeItem(product_id); return; }
    set((s) => ({
      items: s.items.map(i =>
        i.product_id === product_id
          ? { ...i, quantity, total: (i.unit_price * quantity) - i.discount }
          : i
      ),
    }));
  },

  updatePrice: (product_id, unit_price) => {
    set((s) => ({
      items: s.items.map(i =>
        i.product_id === product_id
          ? { ...i, unit_price, total: (unit_price * i.quantity) - i.discount }
          : i
      ),
    }));
  },

  updateItemDiscount: (product_id, discount) => {
    set((s) => ({
      items: s.items.map(i =>
        i.product_id === product_id
          ? { ...i, discount, total: (i.unit_price * i.quantity) - discount }
          : i
      ),
    }));
  },

  removeItem: (product_id) =>
    set((s) => ({ items: s.items.filter(i => i.product_id !== product_id) })),

  setCustomer: (customer) => set({ customer }),
  setDiscount: (discount) => set({ discount: parseFloat(discount) || 0 }),
  setNote:     (note)     => set({ note }),
  setBranch:   (branchId) => set({ branchId }),

  clearCart: () => set({ items: [], customer: null, discount: 0, note: '' }),

  getSubtotal: () => {
    const { items } = get();
    return items.reduce((sum, i) => sum + i.total, 0);
  },

  getTotal: () => {
    const { discount } = get();
    return Math.max(0, get().getSubtotal() - discount);
  },

  getItemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
}));

// ── Settings Store ────────────────────────────────────────
export const useSettingsStore = create(
  persist(
    (set) => ({
      shopName:       'My Retail Shop',
      currency:       'TZS',
      currencySymbol: 'TZS',
      taxRate:        0,
      branchId:       1,

      setSettings: (s) => set({
        shopName:       s.shop_name       || 'My Retail Shop',
        currency:       s.currency        || 'TZS',
        currencySymbol: s.currency_symbol || 'TZS',
        taxRate:        parseFloat(s.tax_rate) || 0,
        branchId:       parseInt(s.pos_branch_id) || 1,
      }),

      formatCurrency: (amount) =>
        `TZS ${parseFloat(amount || 0).toLocaleString('en-TZ', { minimumFractionDigits: 0 })}`,
    }),
    { name: 'pos_settings' }
  )
);
